# -*- coding: utf-8 -*-
# E02 recta y con las habitaciones de testa hacia Ribera de Curtidores.
# Parte de E02_REVISION_TECNICA.3dm (sin tocar el original) y escribe un modelo nuevo.
import json, math, re, copy
import numpy as np
import rhino3dm as r
from shapely.geometry import Polygon, Point, box, LineString
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from layout import *          # TS, TN, P, PN, bathN, bathS, pocketN, pocketS, head, KEEP, S, X0, tx, yN, yS ...
from geo import outline

SRCFILE = 'e02.3dm'
OUTFILE = 'E02_RECTA_HABITACIONES_A_LA_CALLE.3dm'
m = r.File3dm.Read(SRCFILE)
LN = {l.Index: l.Name for l in m.Layers}
LI = {l.Name: l.Index for l in m.Layers}
LEVEL = 4.2


def xf(M):
    t = r.Transform.Identity()
    t.M00, t.M01, t.M03 = M[0, 0], M[0, 1], M[0, 2]
    t.M10, t.M11, t.M13 = M[1, 0], M[1, 1], M[1, 2]
    return t


def name(o): return o.Attributes.Name or ''
def layer(o): return LN[o.Attributes.LayerIndex]
def bb(o):
    b = o.Geometry.GetBoundingBox(); return b.Min, b.Max


# ------------------------------------------------------------------ 1. qué se endereza
FIXED_LAYERS = {'90_CONTEXTO', '91_PARCELA', '25_PUBLICO_FIJO', '26_ESTUDIO_DIARIO', '27_EXPOSICION_DOMINGO',
                '29_AGUA_Y_PAISAJE', '21_NUCLEO_VERTICAL'}
FIXED_NAMES = ('Escalera', 'Meseta', 'Galeria', 'Montante escalera', 'Montante barandilla', 'Hueco de ascensor',
               'Cabina ascensor', 'Pavimento', 'WC PB', 'Techo aseo PB', 'Pared continua de servicios sur',
               'Techo continuo cocina', 'Uso compartido planta baja', 'Mesa colectiva', 'Banco de taller',
               'Almacenaje integrado', 'Asiento comedor PB', 'Cubierta publica', 'Antepecho publico', 'Dintel publico',
               'Carpinteria publica', 'Lucernario publico', 'Corredera publica', 'Pata Silla')
objs = list(m.Objects)
rotated = []
XF = {}            # id -> matriz 3x3 aplicada desde el original
COPIES = {}        # id nuevo -> (id fuente, matriz)
NEWREG = {}        # id nuevo -> polígono exacto

for o in objs:
    n, la = name(o), layer(o)
    lo, hi = bb(o)
    if la in FIXED_LAYERS or n.startswith(FIXED_NAMES):
        continue
    if la in ('19_SOPORTE_PB',) or n.startswith('Placa de apoyo'):
        pass                      # troncos y ramas acompañan a la casa
    elif hi.Z < 3.4:
        continue                  # resto de planta baja: fijo
    if n.startswith('Hoja acceso principal'):
        pass
    o.Geometry.Transform(xf(S))
    rotated.append(str(o.Attributes.Id)); XF[str(o.Attributes.Id)] = S.copy()
print('enderezados', len(rotated))

# ------------------------------------------------------------------ 2. utilidades de geometría
def nohole(p):
    if p.geom_type != 'Polygon':
        return [q for g in getattr(p, 'geoms', []) for q in nohole(g)]
    if not p.interiors:
        return [p]
    cx = Polygon(p.interiors[0]).centroid.x
    x0, y0, x1, y1 = p.bounds
    parts = [p.intersection(box(x0 - 1, y0 - 1, cx, y1 + 1)), p.intersection(box(cx, y0 - 1, x1 + 1, y1 + 1))]
    return [q for g in parts for q in nohole(g) if q.area > 1e-6]


def ext(poly, z0, h, la, nm, mat=None):
    out = []
    for p in nohole(poly):
        if p.area < 1e-5:
            continue
        p = orient(p.simplify(.0008, preserve_topology=True), sign=1)
        ring = lambda rg: r.PolylineCurve([r.Point3d(x, y, 0) for x, y in rg.coords])
        e = r.Extrusion.Create(ring(p.exterior), h, True)
        if e is None:
            continue
        for hole in p.interiors:
            e.AddInnerProfile(ring(hole))
        e.Transform(r.Transform.Translation(0, 0, z0))
        a = r.ObjectAttributes(); a.LayerIndex = LI[la]; a.Name = nm
        nid = m.Objects.AddExtrusion(e, a); out.append(nid); NEWREG[str(nid)] = p
    return out


def tube(p0, p1, rad=.016, seg=10):
    p0, p1 = np.array(p0, float), np.array(p1, float)
    d = p1 - p0; L = np.linalg.norm(d)
    if L < 1e-6:
        return None
    d /= L
    a = np.array([0, 0, 1.]) if abs(d[2]) < .9 else np.array([1., 0, 0])
    u = np.cross(d, a); u /= np.linalg.norm(u); v = np.cross(d, u)
    me = r.Mesh()
    for c in (p0, p1):
        for k in range(seg):
            t = 2 * math.pi * k / seg
            q = c + rad * (math.cos(t) * u + math.sin(t) * v)
            me.Vertices.Add(*q)
    for k in range(seg):
        k2 = (k + 1) % seg
        me.Faces.AddFace(k, k2, seg + k2, seg + k)
    me.Normals.ComputeNormals(); me.Compact()
    return me


def add_mesh_tubes(segs, rad, la, nm):
    me = r.Mesh()
    for p0, p1 in segs:
        t = tube(p0, p1, rad)
        if t is not None:
            me.Append(t)
    me.Normals.ComputeNormals(); me.Compact()
    a = r.ObjectAttributes(); a.LayerIndex = LI[la]; a.Name = nm
    return m.Objects.AddMesh(me, a)


import json as _j
from shapely.affinity import affine_transform as _aff
_EX = {x['id']: x for x in _j.load(open('/mnt/user-data/uploads/T7/G3 Proyectos/G3_PLANOS_TECNICOS_2026-10-20/verificacion/EXTRACCION_REVISION_RHINO.json'))[1]['objects']}
def region_ex(ob):
    from shapely.geometry import Polygon as _P, Point as _Pt, LineString as _L
    from shapely.ops import polygonize as _pz
    cl = lambda g: g if g.is_valid else g.buffer(0)
    ps = [p for p in ob['profiles'] if len(p) > 3 and _Pt(p[0][:2]).distance(_Pt(p[-1][:2])) < .002]
    if ps:
        return cl(_P([q[:2] for q in ps[0]], [[q[:2] for q in p] for p in ps[1:]]))
    caps = []
    for face in ob['caps']:
        outer = next((p['points'] for p in face if p['outer']), None)
        if outer:
            caps.append(cl(_P([q[:2] for q in outer], [[q[:2] for q in p['points']] for p in face if not p['outer']])))
    if caps:
        return unary_union(caps)
    out = _P(); lines = []
    for pp in ob['sections']:
        if len(pp) > 3 and _Pt(pp[0][:2]).distance(_Pt(pp[-1][:2])) < .002:
            out = out.symmetric_difference(cl(_P([q[:2] for q in pp])))
        elif len(pp) > 1:
            lines.append(_L([q[:2] for q in pp]))
    if lines:
        out = out.union(unary_union(list(_pz(unary_union(lines)))))
    return out
def mapply(M, g):
    return _aff(g, [M[0, 0], M[0, 1], M[1, 0], M[1, 1], M[0, 2], M[1, 2]])
def fp(o):
    k = str(o.Attributes.Id)
    if k in _EX:
        g = region_ex(_EX[k])
        if not g.is_empty:
            return mapply(XF.get(k, np.eye(3)), g).buffer(0)
    if k in NEWREG:
        return NEWREG[k]
    g = outline(o.Geometry)
    return g.buffer(0) if g is not None else None


# ------------------------------------------------------------------ 3. habitaciones de testa
door_leaf = {o for o in objs if name(o).startswith('Hoja dormitorio')}
lintels = [o for o in objs if re.match(r'Dintel_\d+_', name(o))]
def room_lintel(h):
    d = next(o for o in objs if name(o) == f'Hoja dormitorio {h}')
    lo, hi = bb(d); c = Point((lo.X + hi.X) / 2, (lo.Y + hi.Y) / 2)
    return min(lintels, key=lambda o: Point((bb(o)[0].X + bb(o)[1].X) / 2, (bb(o)[0].Y + bb(o)[1].Y) / 2).distance(c))

def room_set(h):
    s = [o for o in objs if name(o).startswith(h + ' ') or name(o) == f'Hoja dormitorio {h}']
    s.append(room_lintel(h))
    return s

# H05 original fuera; H07 se gira; H05 nueva se copia de H01 (misma mano que necesita)
for o in room_set('H05'):
    m.Objects.Delete(o.Attributes.Id)
D7 = TN['H07'] @ np.linalg.inv(TS['H07'])
for o in room_set('H07'):
    o.Geometry.Transform(xf(D7)); XF[str(o.Attributes.Id)] = D7 @ XF.get(str(o.Attributes.Id), np.eye(3))
D5 = TN['H05'] @ np.linalg.inv(TS['H01'])
for o in room_set('H01'):
    g = o.Geometry.Duplicate(); g.Transform(xf(D5))
    a = r.ObjectAttributes(); a.LayerIndex = o.Attributes.LayerIndex; a.Name = name(o).replace('H01', 'H05')
    nid = m.Objects.Add(g, a); COPIES[str(nid)] = (str(o.Attributes.Id), D5 @ XF.get(str(o.Attributes.Id), np.eye(3)))

# ------------------------------------------------------------------ 4. baños de la testa a los bolsillos
podW = apply(S, __import__('pickle').load(open('rooms.pkl', 'rb'))['pod'])
px0, py0, px1, py1 = podW.bounds
pc = podW.centroid
pod_objs = []
for o in objs:
    if not m.Objects.FindId(o.Attributes.Id):
        continue
    n, la = name(o), layer(o)
    if la not in ('15_BANOS', '12_AGUA', '22_PUERTAS', '23_PATINILLOS', '24_MONTANTES_EN_SERVICIOS', '01_MUROS', '17_CUBIERTA_TERMICA'):
        continue
    if la == '01_MUROS' and not re.match(r'Dintel_\d+_', n):
        continue
    if la == '22_PUERTAS' and not n.startswith('Corredera bano'):
        continue
    lo, hi = bb(o)
    if hi.Z < 3.5:
        continue
    g = fp(o)
    c = g.representative_point() if g is not None and not g.is_empty else Point((lo.X + hi.X) / 2, (lo.Y + hi.Y) / 2)
    if podW.buffer(.05).contains(c):
        pod_objs.append(o)
roofW = [o for o in pod_objs if name(o).startswith('Techo completo de servicios')]
for o in roofW:
    m.Objects.Delete(o.Attributes.Id)
pod_objs = [o for o in pod_objs if o not in roofW]
# puertas correderas: definen la cara de acceso de cada baño antiguo
def ycen(o):
    g = fp(o)
    if g is not None and not g.is_empty:
        return g.centroid.y
    lo, hi = bb(o); return (lo.Y + hi.Y) / 2
cor = sorted([o for o in pod_objs if name(o).startswith('Corredera')], key=ycen)
yd_S, yd_N = ycen(cor[0]), ycen(cor[1])           # puerta del baño sur (abajo) y norte (arriba)
mid = (yd_S + yd_N) / 2
west_in = px0 + .12                               # cara interior oeste del bloque antiguo
dxN = (bathN.bounds[0] + .06) - west_in
dxS = (bathS.bounds[0] + .06) - west_in
dyN = bathN.bounds[1] - yd_N
dyS = bathS.bounds[3] - yd_S
moves = {}
for o in pod_objs:
    north = ycen(o) > mid
    d = (dxN, dyN) if north else (dxS, dyS)
    o.Geometry.Transform(r.Transform.Translation(d[0], d[1], 0))
    moves[str(o.Attributes.Id)] = ('N' if north else 'S', d)
    XF[str(o.Attributes.Id)] = trans(d[0], d[1]) @ XF.get(str(o.Attributes.Id), np.eye(3))
print('baños movidos', len(pod_objs), 'N', (round(dxN, 2), round(dyN, 2)), 'S', (round(dxS, 2), round(dyS, 2)))

# ------------------------------------------------------------------ 5. suelo y muros
zoneW = ZONE
notchN = box(tx - 1.6, yN, tx, yN + 1.45).difference(PN['H07']['room'])
notchS = box(tx - 1.6, yS - 1.45, tx, yS).difference(PN['H05']['room'])
west_parts = unary_union([PN['H07']['room'], PN['H05']['room'], pocketN, pocketS, head, notchN, notchS])
for o in list(m.Objects):
    if name(o).startswith('Suelo continuo'):
        slab_old = fp(o); m.Objects.Delete(o.Attributes.Id)
slab_keep = slab_old.intersection(KEEP)
slab_new = unary_union([slab_keep, west_parts.buffer(.06, join_style=2)]).buffer(.002).buffer(-.002)
ext(slab_new, LEVEL - .18, .18, '00_SUELO', 'Suelo continuo a cota +4,20 / E02 recta')

# muros antiguos: se recortan fuera de la testa
for o in list(m.Objects):
    if layer(o) == '01_MUROS' and name(o).startswith('Muros continuos'):
        g = fp(o)
        if g is None:
            continue
        if g.intersects(zoneW):
            k = g.difference(zoneW)
            m.Objects.Delete(o.Attributes.Id)
            if k.area > 1e-4:
                ext(k, LEVEL, 2.75, '01_MUROS', 'Muros continuos revisados / banos integrados')
# vidrios comunes que quedaban en la testa
for o in list(m.Objects):
    if name(o).startswith('Paño comun operable'):
        g = fp(o)
        if g is not None and g.centroid.within(zoneW):
            m.Objects.Delete(o.Attributes.Id)

# muros nuevos de la testa
H = 2.75
env = unary_union([slab_keep.buffer(.001), west_parts])
ring = env.boundary.buffer(.06, join_style=2).intersection(ZONE.buffer(.08, join_style=2))
rooms_ring = unary_union([PN[h]['room'].boundary.buffer(.06, join_style=2) for h in PN])
baths_ring = unary_union([b.boundary.buffer(.06, join_style=2) for b in (bathN, bathS)])
# filtros: tabique en la boca de cada rellano, dejando paso de 1,05 m junto a la habitación
gap = 1.05
screenN = box(tx + .06 + gap, yN - .06, H08x0, yN + .06)
screenS = box(tx + .06 + gap, yS - .06, H06x0, yS + .06)
walls_new = unary_union([ring, rooms_ring, baths_ring, screenN, screenS])
# huecos: puertas de habitación, bows, correderas de baño y vidrio a la calle
holes = [PN[h]['door'].buffer(.02) for h in PN] + [PN[h]['win'].buffer(.02) for h in PN]
for o in m.Objects:
    if name(o).startswith('Corredera bano') and str(o.Attributes.Id) in moves:
        g = fp(o)
        holes.append(g.buffer(.09, cap_style=2))
street = box(X0 - .2, yS + .45, X0 + .2, yN - .45)
holes.append(street)
walls_new = walls_new.difference(unary_union(holes)).difference(unary_union([PN[h]['room'].buffer(-.06) for h in PN]))
walls_new = walls_new.intersection(ZONE.buffer(.08, join_style=2)).union(walls_new.intersection(screenN.union(screenS)))
print('walls_new parts', [[round(v,2) for v in q.bounds] for q in (walls_new.geoms if walls_new.geom_type!='Polygon' else [walls_new])])
ext(walls_new, LEVEL, H, '01_MUROS', 'Muros continuos / testa a la calle')
# vidrio, antepecho y dintel del frente común a la calle
glass = street.intersection(env.boundary.buffer(.05, join_style=2))
ext(glass, LEVEL + .45, 1.95, '06_VIDRIO', 'Paño comun operable a la calle')
ext(street.intersection(env.boundary.buffer(.06, join_style=2)), LEVEL, .45, '01_MUROS', 'Antepecho comun a la calle')
ext(street.intersection(env.boundary.buffer(.06, join_style=2)), LEVEL + 2.40, .35, '01_MUROS', 'Dintel comun a la calle')
# dinteles de las correderas de baño (las nuevas aberturas en muro)
for o in m.Objects:
    pass

# ------------------------------------------------------------------ 6. cubiertas de la testa
ext(bathN.buffer(.06, join_style=2), LEVEL + H, .14, '17_CUBIERTA_TERMICA', 'Techo completo de servicios norte / testa')
ext(bathS.buffer(.06, join_style=2), LEVEL + H, .14, '17_CUBIERTA_TERMICA', 'Techo completo de servicios sur / testa')
vela = None
for o in m.Objects:
    if name(o).startswith('Cubierta comun bajo sobretecho'):
        vela = fp(o)
open_roof = unary_union([pocketN, pocketS, head, notchN, notchS]).difference(unary_union([bathN, bathS]).buffer(.06))
if vela is not None:
    open_roof = open_roof.difference(vela)
ext(open_roof.buffer(.06, join_style=2).intersection(slab_new), LEVEL + H, .14, '17_CUBIERTA_TERMICA', 'Cubierta comun de la testa / espesor de estudio')

# ------------------------------------------------------------------ 7. bandeja estructural sobre el nuevo borde
for o in list(m.Objects):
    if name(o).startswith(('Cordon superior bandeja', 'Cordon inferior bandeja', 'Diagonal bandeja')):
        m.Objects.Delete(o.Attributes.Id)
edge = slab_new.buffer(-.02, join_style=2)
rings = [edge.exterior] if edge.geom_type == 'Polygon' else [p.exterior for p in edge.geoms]
segs_sup, segs_inf, segs_d = [], [], []
for rg in rings:
    L = rg.length
    pts = [rg.interpolate(t) for t in np.arange(0, L, .25)] + [rg.interpolate(0)]
    for a, b_ in zip(pts[:-1], pts[1:]):
        segs_sup.append(((a.x, a.y, 3.98), (b_.x, b_.y, 3.98)))
        segs_inf.append(((a.x, a.y, 3.68), (b_.x, b_.y, 3.68)))
    n = max(4, int(L / .8))
    for k in range(n):
        s0 = L * k / n; s1 = L * (k + 1) / n
        p0 = rg.interpolate(s0); p1 = rg.interpolate(s1)
        if k % 2 == 0:
            segs_d.append(((p0.x, p0.y, 3.68), (p1.x, p1.y, 3.98)))
        else:
            segs_d.append(((p0.x, p0.y, 3.98), (p1.x, p1.y, 3.68)))
add_mesh_tubes(segs_sup, .033, '07_ACERO', 'Cordon superior bandeja')
add_mesh_tubes(segs_inf, .033, '07_ACERO', 'Cordon inferior bandeja')
add_mesh_tubes(segs_d, .016, '07_ACERO', 'Diagonal bandeja')
print('diagonales', len(segs_d))

# ------------------------------------------------------------------ 8. mástiles de la testa
def mesh_c(o):
    V = np.array([[v.X, v.Y, v.Z] for v in o.Geometry.Vertices]); return V
targets = []
for o in list(m.Objects):
    if name(o).startswith('Mastil en borde'):
        V = mesh_c(o); c = V[:, :2].mean(0)
        if Point(*c).within(zoneW.buffer(-.0)) or not slab_new.buffer(.15).contains(Point(*c)) or unary_union([PN[h]['room'] for h in PN]+[bathN,bathS]).contains(Point(*c)):
            targets.append((o, c))
spots = [(X0 + .25, yN - .15), (X0 + .25, yS + .15), (tx + .06 + gap + .1, yS + .02), (tx + .06 + gap + .1, yN - .02)]
used = []
for o, c in targets:
    s = min([q for q in spots if q not in used], key=lambda q: math.dist(q, c))
    used.append(s); d = (s[0] - c[0], s[1] - c[1])
    o.Geometry.Transform(r.Transform.Translation(d[0], d[1], 0))
    for q in list(m.Objects):
        if name(q).startswith('Rama sobre circulacion'):
            V = mesh_c(q); lowp = V[V[:, 2].argmin(), :2]
            if math.dist(lowp, c) < .6:
                q.Geometry.Transform(r.Transform.Translation(d[0], d[1], 0))
print('mastiles recolocados', len(targets))

m.Strings['ESTADO'] = ('E02 recta (0/90 grados, se corrigen los 2,09 grados) y con las dos habitaciones de testa '
                       'mirando a Ribera de Curtidores. Los dos baños de esa casa pasan a bolsillos junto a las medianeras. '
                       'Anteproyecto: estructura, instalaciones y normativa por comprobar.')
assert m.Write(OUTFILE, 8)
import pickle as _pk
_pk.dump({'XF': XF, 'COPIES': COPIES, 'NEWREG': NEWREG}, open('xf_registry.pkl', 'wb'))
json.dump({'moves': {k: [v[0], list(v[1])] for k, v in moves.items()}, 'D5': D5.tolist(), 'D7': D7.tolist(), 'S': S.tolist(),
           'dN': [dxN, dyN], 'dS': [dxS, dyS]}, open('build_meta.json', 'w'))
print('ok', OUTFILE)
