from e02geo import *
import pickle
B=pickle.load(open('/home/claude/giro/base.pkl','rb')); PARCEL=B['parcel']; SLAB0=B['slab']; WALLS0=B['walls']
C0=SLAB0.centroid
S=rot(-TILT,C0.x,C0.y)                      # enderezar
def straight(g): return apply(S,g)
TS={h:S@T0[h] for h in ROOMS}               # habitaciones rectas
P={h:room_parts(TS[h]) for h in ROOMS}
H06x0=P['H06']['room'].bounds[0]; H08x0=P['H08']['room'].bounds[0]
yN=P['H08']['room'].bounds[1]               # cara sur de H08 = borde norte del pasillo
yS=P['H06']['room'].bounds[3]               # cara norte de H06 = borde sur del pasillo
X0=13.30                                    # punta de la bow hacia la calle
tx=X0+4.9
# H07': espejada (como la original). local x -> -y, local y -> -x
TN={}
TN['H07']=np.array([[0,-1,tx],[-1,0,yN+4.7],[0,0,1.]])
# H05': propia (se copia de H01). local x -> +y, local y -> -x
TN['H05']=np.array([[0,-1,tx],[1,0,yS-4.7],[0,0,1.]])
PN={h:room_parts(TN[h]) for h in TN}
SRC={'H07':'H07','H05':'H01'}               # de que habitacion se copia el conjunto
W_IN=0.06                                   # medio espesor de muro
# bolsillos: entre la habitacion de testa y H08 / H06
pxN0=tx+W_IN; pxN1=H08x0-W_IN; pxS0=tx+W_IN; pxS1=H06x0-W_IN
dN=PN['H07']['door'].bounds; dS=PN['H05']['door'].bounds
bathN=box(pxN0, dN[3]+.15+W_IN, pxN1, PN['H07']['room'].bounds[3])
bathS=box(pxS0, PN['H05']['room'].bounds[1], pxS1, dS[1]-.15-W_IN)
pocketN=box(tx, yN, H08x0, PN['H07']['room'].bounds[3])
pocketS=box(tx, PN['H05']['room'].bounds[1], H06x0, yS)
head=box(X0+.6, yS, H06x0+.2, yN)          # pasillo prolongado hasta la calle (entre bows)
head=box(X0+0.0, yS, max(H06x0,H08x0), yN).difference(unary_union([PN[h]['room'] for h in PN]).buffer(-.001))
# corte: lo que queda del modelo original
ZONE=unary_union([box(0,-.001,H08x0-.07,60), box(0,-60,H06x0-.07,.001)])
KEEP=box(0,-60,999,60).difference(ZONE)
if __name__=='__main__':
    print('tilt',TILT,'C0',C0)
    print('H06x0',H06x0,'H08x0',H08x0,'yN',yN,'yS',yS)
    for h in PN: print(h,[round(v,2) for v in PN[h]['room'].bounds],'door',[round(v,2) for v in PN[h]['door'].bounds])
    print('bathN',[round(v,2) for v in bathN.bounds],round(bathN.bounds[2]-bathN.bounds[0],2),round(bathN.bounds[3]-bathN.bounds[1],2))
    print('bathS',[round(v,2) for v in bathS.bounds],round(bathS.bounds[2]-bathS.bounds[0],2),round(bathS.bounds[3]-bathS.bounds[1],2))
    allr=unary_union([P[h]['room'] for h in ROOMS if h not in PN]+[PN[h]['room'] for h in PN]+[bathN,bathS,pocketN,pocketS,head])
    print('fuera de parcela',round(allr.difference(PARCEL).area,3))
    for h in ROOMS:
        p=PN[h]['room'] if h in PN else P[h]['room']
        o=unary_union([p,(PN[h] if h in PN else P[h])['textile'].buffer(.03)]).difference(PARCEL).area
        if o>0.001: print(' sale',h,round(o,3))
