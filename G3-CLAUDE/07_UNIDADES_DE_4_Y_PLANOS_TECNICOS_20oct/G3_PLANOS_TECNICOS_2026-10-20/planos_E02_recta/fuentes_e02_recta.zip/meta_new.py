# Metadatos de dibujo (puertas, patinillos, ejes de bow) llevados a la E02 recta.
import json, numpy as np
from layout import S, TN, TS
B=json.load(open('build_meta.json'))
D5=np.array(B['D5']); D7=np.array(B['D7']); dN=B['dN']; dS=B['dS']
M=json.load(open('/mnt/user-data/uploads/T7/G3 Proyectos/G3_PLANOS_TECNICOS_2026-10-20/verificacion/REVISION_GEOMETRICA.json'))[3]
def ap(Mx,p): q=Mx@np.array([p[0],p[1],1.]); return [float(q[0]),float(q[1])]
def tr(p,d): return [p[0]+d[0],p[1]+d[1]]
KEYS=['p0','p1','pocket_end','hinge','closed','open']
def move(item,f):
    it=dict(item)
    for k in KEYS+['center']:
        if k in it: it[k]=f(it[k])
    return it
doors=[];axes=[];shafts=[]
byid={d['id']:d for d in M['doors']}
for d in M['doors']:
    i=d['id']
    if i=='H05': continue
    if i=='H07': doors.append(move(d,lambda p:ap(D7,ap(S,p)))); continue
    if i=='B3': doors.append(move(d,lambda p:tr(ap(S,p),dN))); continue
    if i=='B4': doors.append(move(d,lambda p:tr(ap(S,p),dS))); continue
    doors.append(move(d,lambda p:ap(S,p)))
h5=move(byid['H01'],lambda p:ap(D5,ap(S,p))); h5['id']='H05'; doors.append(h5)
for a in M['bow_axes']:
    i=a['id']
    if i=='S05': continue
    if i=='S07': axes.append(move(a,lambda p:ap(D7,ap(S,p)))); continue
    axes.append(move(a,lambda p:ap(S,p)))
s5=move([a for a in M['bow_axes'] if a['id']=='S01'][0],lambda p:ap(D5,ap(S,p))); s5['id']='S05'; axes.append(s5)
for s in M['shafts']:
    i=s['id']
    f={'P3':lambda p:tr(ap(S,p),dN),'P4':lambda p:tr(ap(S,p),dS)}.get(i,lambda p:ap(S,p))
    shafts.append({'id':i,'center':f(s['center'])})
META={'code':'E02','level':4.2,'doors':doors,'bow_axes':axes,'shafts':shafts,'baths':[0,0,0,0]}
json.dump(META,open('meta_e02_recta.json','w'),indent=1)
print(len(doors),len(axes),len(shafts))
