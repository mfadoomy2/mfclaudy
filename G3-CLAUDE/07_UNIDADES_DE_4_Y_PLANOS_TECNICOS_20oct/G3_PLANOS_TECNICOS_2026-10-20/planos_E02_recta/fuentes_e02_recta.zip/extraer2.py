import rhino3dm as r, pickle, json, numpy as np, sys
sys.argv=['x']
from shapely.affinity import affine_transform
EX={x['id']:x for x in json.load(open('/mnt/user-data/uploads/T7/G3 Proyectos/G3_PLANOS_TECNICOS_2026-10-20/verificacion/EXTRACCION_REVISION_RHINO.json'))[1]['objects']}
REG=pickle.load(open('xf_registry.pkl','rb'))
exec(open('build.py').read().split("def region_ex(ob):")[0].split("import json as _j")[0][:0])
src=open('build.py').read()
i=src.index("def region_ex(ob):"); j=src.index("def mapply(M, g):")
from shapely.geometry import box
from shapely.ops import unary_union
exec(src[i:j])
def mapply(M,g): return affine_transform(g,[M[0,0],M[0,1],M[1,0],M[1,1],M[0,2],M[1,2]])
m=r.File3dm.Read('E02_RECTA_HABITACIONES_A_LA_CALLE.3dm'); LN={l.Index:l.Name for l in m.Layers}
out=[]; stats={'ex':0,'copy':0,'new':0,'none':0}
for o in m.Objects:
    k=str(o.Attributes.Id); g=o.Geometry; b=g.GetBoundingBox()
    bbox=[[b.Min.X,b.Min.Y,b.Min.Z],[b.Max.X,b.Max.Y,b.Max.Z]]
    reg=None
    if k in REG['COPIES']:
        s,M=REG['COPIES'][k]; e=EX[s]; reg=mapply(M,region_ex(e)); bbox=[[bbox[0][0],bbox[0][1],e['bbox'][0][2]],[bbox[1][0],bbox[1][1],e['bbox'][1][2]]]; stats['copy']+=1
    elif k in EX:
        e=EX[k]; reg=mapply(REG['XF'].get(k,np.eye(3)),region_ex(e)); bbox=[[bbox[0][0],bbox[0][1],e['bbox'][0][2]],[bbox[1][0],bbox[1][1],e['bbox'][1][2]]]; stats['ex']+=1
    elif k in REG['NEWREG']:
        reg=REG['NEWREG'][k]; stats['new']+=1
    else: stats['none']+=1
    if reg is not None and not reg.is_empty:
        x0,y0,x1,y1=reg.bounds; bbox=[[x0,y0,bbox[0][2]],[x1,y1,bbox[1][2]]]
    out.append(dict(id=k,layer=LN[o.Attributes.LayerIndex],name=o.Attributes.Name or '',type=type(g).__name__,bbox=bbox,region=reg))
pickle.dump(out,open('ex_new.pkl','wb')); print(stats,len(out))
