import json,pickle,math,sys,io,contextlib
import numpy as np
sys.path.insert(0,'/home/claude/g3/w/G3_DOCUMENTO_PLANTAS_NUEVAS_CORREGIDAS_2026-10-19/fuentes')
with contextlib.redirect_stdout(io.StringIO()): import geometria as G
from shapely.geometry import Polygon, Point, box
from shapely.affinity import affine_transform, rotate, translate
from shapely.ops import unary_union
rows={x['id']:x for x in json.load(open('/home/claude/giro/objs.json'))}
out=pickle.load(open('/home/claude/giro/outlines.pkl','rb'))
def getg(name):
    return unary_union([out[k] for k,r in rows.items() if r['name'].startswith(name) and out[k] is not None])
def fit(h):
    bed=getg(h+' colchon'); desk=getg(h+' tablero'); gl=getg(h+' vidrio curvo')
    L=np.array([[G.BED.centroid.x,G.BED.centroid.y],[G.DESK.centroid.x,G.DESK.centroid.y],[G.WIN.centroid.x,G.WIN.centroid.y]])
    W=np.array([[bed.centroid.x,bed.centroid.y],[desk.centroid.x,desk.centroid.y],[gl.centroid.x,gl.centroid.y]])
    lc=L.mean(0); wc=W.mean(0)
    U_,S,Vt=np.linalg.svd((W-wc).T@(L-lc)); Rm=U_@Vt; t=wc-Rm@lc
    return np.array([[Rm[0,0],Rm[0,1],t[0]],[Rm[1,0],Rm[1,1],t[1]],[0,0,1]])
ROOMS=[f'H0{i}' for i in range(1,9)]
T0={h:fit(h) for h in ROOMS}   # matrices 3x3 local->mundo (estado actual)
def apply(M,g):
    return affine_transform(g,[M[0,0],M[0,1],M[1,0],M[1,1],M[0,2],M[1,2]])
def rot(deg,cx,cy):
    a=math.radians(deg);c,s=math.cos(a),math.sin(a)
    return np.array([[c,-s,cx-c*cx+s*cy],[s,c,cy-s*cx-c*cy],[0,0,1]])
def trans(dx,dy): return np.array([[1,0,dx],[0,1,dy],[0,0,1]])
def room_parts(M):
    d={'room':G.ROOM,'win':G.WIN,'door':G.DOOR,'bed':G.BED,'desk':G.DESK,'ward':G.WARD,'seat':G.SEAT,'stool':G.STOOL,'textile':G.TEXTILE}
    return {k:apply(M,v) for k,v in d.items()}
TILT=math.degrees(math.atan2(T0['H03'][1,0],T0['H03'][0,0]))  # 2,09
