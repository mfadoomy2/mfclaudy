import rhino3dm as r, math
from shapely.geometry import Polygon, LineString, MultiPoint
from shapely.ops import unary_union, linemerge
def curve_pts(c, n=200):
    if isinstance(c, r.PolylineCurve):
        return [(c.Point(i).X, c.Point(i).Y, c.Point(i).Z) for i in range(c.PointCount)]
    if isinstance(c, r.LineCurve):
        return [(c.PointAtStart.X, c.PointAtStart.Y, c.PointAtStart.Z), (c.PointAtEnd.X, c.PointAtEnd.Y, c.PointAtEnd.Z)]
    d = c.Domain
    return [(p.X, p.Y, p.Z) for p in (c.PointAt(d.T0 + (d.T1 - d.T0) * i / n) for i in range(n + 1))]
def outline(geom, n=None):
    """Huella XY: anillos de la cara inferior (par-impar). Si no hay cara plana abajo, envolvente convexa."""
    if isinstance(geom, r.Extrusion):
        b = geom.ToBrep(True)
    elif isinstance(geom, r.Brep):
        b = geom
    else:
        return None
    if b is None:
        return None
    z0 = b.GetBoundingBox().Min.Z
    segs, allp = [], []
    for e in b.Edges:
        c = e.EdgeCurve if hasattr(e, 'EdgeCurve') else e
        pts = curve_pts(c)
        allp += [(p[0], p[1]) for p in pts]
        if all(abs(p[2] - z0) < 1e-4 for p in pts):
            segs.append(LineString([(p[0], p[1]) for p in pts]))
    region = Polygon()
    if segs:
        merged = linemerge(unary_union(segs))
        lines = [merged] if merged.geom_type == 'LineString' else list(getattr(merged, 'geoms', []))
        for ln in lines:
            if ln.is_ring and len(ln.coords) >= 4:
                pg = Polygon(ln.coords)
                if not pg.is_valid:
                    pg = pg.buffer(0)
                region = region.symmetric_difference(pg)
    if region.is_empty and len(allp) > 2:
        region = MultiPoint(allp).convex_hull
    return region if not region.is_empty else None
