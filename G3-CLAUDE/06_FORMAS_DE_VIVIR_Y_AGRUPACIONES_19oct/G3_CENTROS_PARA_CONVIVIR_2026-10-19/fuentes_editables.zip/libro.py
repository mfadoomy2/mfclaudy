# -*- coding: utf-8 -*-
# Cuaderno A3 maquetado como la bitácora de Integración: Ibarra Real Nova, fondo blanco,
# numerales grandes, títulos en cursiva, lema, texto corto y leyendas a, b, c.
import sys, json
sys.path.insert(0, '/home/claude/g3/build')
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.platypus import Paragraph, Frame
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from pypdf import PdfReader
import pikepdf
from contenido import *

F = Path('/home/claude/g3/fonts')
pdfmetrics.registerFont(TTFont('Ib', str(F / 'IbarraRealNova-Regular.ttf')))
pdfmetrics.registerFont(TTFont('IbI', str(F / 'IbarraRealNova-Italic.ttf')))
pdfmetrics.registerFont(TTFont('IbB', str(F / 'IbarraRealNova-SemiBold.ttf')))
registerFontFamily('Ib', normal='Ib', italic='IbI', bold='IbB', boldItalic='IbI')

FIG = Path('/home/claude/g3/build/fig')
OUT = Path('/home/claude/g3/build/out')
OUT.mkdir(exist_ok=True)
W, H = 420, 297  # mm
INK = HexColor('#141414')
GREY = HexColor('#8A8A8A')
PINK = HexColor('#D63C8A')
CYAN = HexColor('#12A9AE')
GOLD = HexColor('#D9A21E')
VIOLET = HexColor('#7E52B8')
GREEN = HexColor('#3E9E6E')
ML, MR, MT, MB = 14, 14, 20, 20
X0, X1, Y0, Y1 = ML, W - MR, MT, H - MB
NTOT = 10
INFO = json.load(open(FIG / 'plantas_info.json'))


def fsize(name):
    b = PdfReader(str(FIG / (name + '.pdf'))).pages[0].mediabox
    return float(b.width) / mm, float(b.height) / mm


class Book:
    def __init__(s, path):
        s.path = path
        s.c = canvas.Canvas(str(path), pagesize=(W * mm, H * mm))
        s.c.setTitle('Centros para convivir · Cuaderno de plantas')
        s.c.setAuthor('G3 Proyectos · UEM')
        s.page = 0
        s.figs = []      # (page_index, name, x, y, w, h) en mm desde arriba-izquierda
        s.toc = {}

    # ---------------- texto
    def text(s, txt, x, y, font='Ib', size=10, color=INK, anchor='l'):
        s.c.setFillColor(color)
        s.c.setFont(font, size)
        {'l': s.c.drawString, 'r': s.c.drawRightString, 'c': s.c.drawCentredString}[anchor](x * mm, (H - y) * mm, txt)

    def para(s, html, x, y, w, h, size=10.4, lead=None, font='Ib', color=INK, space=0, valign='t'):
        st = ParagraphStyle('p', fontName=font, fontSize=size, leading=lead or size * 1.45, textColor=color,
                            alignment=TA_LEFT, spaceAfter=space, hyphenationLang='es_ES' if size < 14 else '', embeddedHyphenation=1,
                            uriWasteReduce=0.3)
        ps = [Paragraph(t, st) for t in (html if isinstance(html, list) else [html])]
        tot = 0
        for p in ps:
            _, ph = p.wrap(w * mm, h * mm)
            tot += ph + space
        tot = (tot - space) / mm
        if valign == 'b':
            y = y + h - tot - .5
            h = tot + 1.5
        fr = Frame(x * mm, (H - y - h) * mm, w * mm, h * mm, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        rest = fr.addFromList(ps, s.c)
        if ps:
            print('  !! no cabe:', (html if isinstance(html, str) else html[0])[:50])
        return tot

    def measure(s, html, w, size, lead, font='Ib'):
        st = ParagraphStyle('m', fontName=font, fontSize=size, leading=lead)
        return Paragraph(html, st).wrap(w * mm, 1000 * mm)[1] / mm

    # ---------------- figuras (se incrustan después como vector)
    def fig(s, name, x, y, w=None, h=None, align='l', valign='t', scale=1.0):
        """Coloca una figura. Por defecto a tamaño natural (escala real). w/h limitan y centran."""
        fw, fh = fsize(name)
        fw, fh = fw * scale, fh * scale
        if w is not None and h is not None:
            k = min(1.0 if scale == 1.0 else 9, w / fw, h / fh) if (fw > w or fh > h) else 1.0
            if k < 1:
                print('  reducida', name, round(k, 3))
            fw, fh = fw * k, fh * k
            x = x + {'l': 0, 'c': (w - fw) / 2, 'r': w - fw}[align]
            y = y + {'t': 0, 'c': (h - fh) / 2, 'b': h - fh}[valign]
        s.figs.append((s.page - 1, name, x, y, fw, fh))
        return x, y, fw, fh

    def cap(s, letter, txt, x, y, w=120, size=8, color=INK):
        if letter:
            s.text(letter, x, y, 'IbI', size, PINK)
            s.para(txt, x + 3.8, y - size * .36 / 2.8346 * 2.2, w - 3.8, 30, size=size, lead=size * 1.35, font='IbI', color=color)
        else:
            s.para(txt, x, y - size * .36 / 2.8346 * 2.2, w, 30, size=size, lead=size * 1.35, font='IbI', color=color)

    def furniture(s, chap=None):
        s.page += 1
        s.text(str(s.page), ML, H - 9.5, 'IbI', 9, INK)
        if chap:
            s.text(f'{chap} / {NTOT:02d}', W - MR, H - 9.5, 'IbI', 9, INK, anchor='r')

    def nextpage(s):
        s.c.showPage()

    def save(s):
        s.c.save()


def opener_block(b, n, x, y, w, h, num_size=190, title_size=40):
    m = CAP[n]
    b.toc[n] = b.page
    b.text(n, x - 1.5, y + num_size * .72 / 2.8346, 'Ib', num_size, INK)
    ty = y + num_size * .72 / 2.8346 + 12
    b.para(m['t'], x, ty, w, 60, size=title_size, lead=title_size * 1.02, font='IbI')
    th = b.measure(m['t'], w, title_size, title_size * 1.02, 'IbI')
    ly = ty + th + 6
    b.para(m['lema'], x, ly, w, 30, size=13, lead=17, font='IbI')
    b.para(m['x'], x, y, w, h, size=10.4, lead=15.2, valign='b')


def legend(b, items, x, y, size=8, gap=4.5, sw='line'):
    for i, (lab, col) in enumerate(items):
        yy = y + i * gap
        b.c.setStrokeColor(col)
        b.c.setFillColor(col)
        if sw == 'line':
            b.c.setLineWidth(1.4)
            b.c.line(x * mm, (H - yy + 1) * mm, (x + 6) * mm, (H - yy + 1) * mm)
        else:
            b.c.rect(x * mm, (H - yy - .2) * mm, 3 * mm, 3 * mm, stroke=0, fill=1)
        b.text(lab, x + 8, yy + 1.9 if sw == 'line' else yy + 2.1, 'IbI', size, INK)


PLANT_LEGEND = [('dormitorio', HexColor('#D8E2D0')), ('cama', HexColor('#C9A97F')), ('tablero y mesas', HexColor('#B9764B')),
                ('vestidor y cocina', HexColor('#6F937F')), ('bow con asiento, estar', HexColor('#CC5F93')),
                ('vidrio', HexColor('#1E9EA3')), ('suelo común', HexColor('#EFE8D9')), ('aseos', HexColor('#9DB8C2'))]


def plant_legend(b, x, y):
    for i, (lab, col) in enumerate(PLANT_LEGEND):
        cx = x + (i % 2) * 46
        cy = y + (i // 2) * 5
        b.c.setFillColor(col)
        b.c.setStrokeColor(HexColor('#B5B5B5'))
        b.c.setLineWidth(.2)
        b.c.rect(cx * mm, (H - cy - .3) * mm, 3.2 * mm, 3.2 * mm, stroke=1 if col.hexval() in ('0xefe8d9', '0xd8e2d0') else 0, fill=1)
        b.text(lab, cx + 5, cy + 2.2, 'IbI', 7.6, INK)


def build():
    b = Book(OUT / 'cuaderno_sin_figuras.pdf')

    # ======================================================= portada
    b.page += 1
    b.fig('planta_V03_S', 196, 34, 214, 240, align='r', valign='c')
    b.text('Centros', ML - 2, 78, 'IbI', 112, INK)
    b.text('para', ML + 20, 114, 'IbI', 112, INK)
    b.text('convivir', ML + 6, 150, 'IbI', 112, INK)
    b.para(PORTADA['sub'], ML, 168, 160, 30, size=22, lead=26, font='IbI')
    b.para(PORTADA['pie1'], ML, 254, 160, 14, size=11)
    b.para(PORTADA['pie2'], ML, 261, 200, 14, size=11, font='IbI')
    b.nextpage()

    # ======================================================= intro
    b.furniture()
    b.para(CITA_INTRO, X0, Y0 + 8, 300, 50, size=46, lead=48, font='IbI')
    # tira de las ocho organizaciones a 1:600
    order = ['V01_U', 'V02_U', 'V03_U', 'V02_P', 'V01_D', 'V01_S', 'V03_D', 'V03_S']
    sizes = [fsize('mini_' + c) for c in order]
    gap = (X1 - X0 - sum(w for w, _ in sizes)) / (len(order) - 1)
    x = X0
    base = 140
    for c, (w, h) in zip(order, sizes):
        b.fig('mini_' + c, x, base - h)
        b.text(UNIDADES[c]['t'], x, base + 5.5, 'IbI', 7.5, INK)
        x += w + gap
    b.text('Las ocho organizaciones a la misma escala. E 1:600', X0, base + 12, 'IbI', 7.5, GREY)
    b.para(INTRO[:2], X0, 160, 122, 117, size=11.2, lead=16.6, space=8, valign='b')
    b.para(INTRO[2:], X0 + 134, 160, 122, 117, size=11.2, lead=16.6, space=8, valign='b')
    b.nextpage()

    # ======================================================= índice (se rellena al final)
    b.furniture()
    idx_page = b.page
    b.nextpage()

    # ======================================================= 01 escenas
    b.furniture('01')
    opener_block(b, '01', X0, Y0 + 2, 96, Y1 - Y0 - 2)

    def card(s, x, y, w):
        hour, title = s['titulo'].split(' / ', 1)
        b.text(s['id'], x, y, 'Ib', 8, PINK)
        b.text(hour, x + 9, y, 'IbI', 8, INK)
        yy = y + 3
        b.para(title[0].upper() + title[1:], x, yy, w, 14, size=16, lead=18, font='IbI')
        yy += b.measure(title, w, 16, 18, 'IbI') + 2.5
        th = b.para(s['escena'], x, yy, w, 30, size=10, lead=13.6)
        yy += th + 2.4
        th = b.para(s['acciones'].replace('→', '·'), x, yy, w, 20, size=9, lead=12, font='IbI', color=GREY)
        yy += th + 2.4
        th = b.para('<i>Necesita</i> · ' + s['condicion'], x, yy, w, 20, size=10, lead=13.6)
        yy += th + 2.4
        b.para(s['critica'], x, yy, w, 20, size=10, lead=13.6, font='IbI')

    cx0 = X0 + 96 + 18
    cw = (X1 - cx0 - 14) / 2
    for i, s in enumerate(SIT[:8]):
        card(s, cx0 + (i % 2) * (cw + 14), Y0 + 4 + (i // 2) * 64, cw)
    b.nextpage()
    b.furniture('01')
    cw = (X1 - X0 - 3 * 12) / 4
    for i, s in enumerate(SIT[8:]):
        card(s, X0 + (i % 4) * (cw + 12), Y0 + 4 + (i // 4) * 128, cw)
    b.nextpage()

    # ======================================================= 02 acercar y proteger
    b.furniture('02')
    opener_block(b, '02', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 18
    _, _, fw, fh = b.fig('red_atractores', fx, Y0 + 2, X1 - fx, 230, align='c', valign='t')
    legend(b, [('proximidad útil, con condiciones', CYAN), ('conflicto: separar en espacio u horario', PINK)], fx + 10, Y0 + 2 + fh + 8)
    b.nextpage()
    b.furniture('02')
    b.para('Cuando dos escenas coinciden, el conflicto se convierte en una exigencia de proyecto.', X0, Y0 + 8, 250, 40, size=30, lead=33, font='IbI')
    for i, (pair, t, r) in enumerate(CRUCES):
        col, row = i % 2, i // 2
        x = X0 + col * 200
        y = Y0 + 70 + row * 46
        b.text(pair, x, y, 'Ib', 9, PINK)
        b.para(t, x, y + 3, 180, 16, size=17, lead=19, font='IbI')
        b.para(r, x, y + 13, 170, 20, size=10.4, lead=15)
    b.nextpage()

    # ======================================================= 03 parcela
    b.furniture('03')
    opener_block(b, '03', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 30
    x, y, fw, fh = b.fig('parcela', fx, Y0 + 2, X1 - fx, Y1 - Y0 - 14, align='c', valign='c')
    b.cap('', 'Parcela y edificios vecinos según Catastro; el gris crece con el número de plantas. E 1:400', x, y + fh + 4, fw)
    b.nextpage()
    b.furniture('03')
    x, y, fw, fh = b.fig('sol_altura', X0, Y0 + 10)
    b.cap('', SOL['cap'], x + 20, y + fh + 6, fw - 20)
    tx = X0 + fw + 28
    tw = X1 - tx
    for i, (big, small) in enumerate([('0,2 – 8,5 h', '21 de diciembre, de la calle a 25,7 m'), ('0,9 – 12,0 h', '21 de marzo'), ('8,0 – 14,7 h', '21 de junio')]):
        yy = Y0 + 16 + i * 26
        b.text(big, tx, yy + 10, 'IbI', 30, [PINK, CYAN, GOLD][i])
        b.text(small, tx, yy + 17, 'IbI', 9, INK)
    b.para(SOL['x'], tx, 120, tw, 150, size=11.2, lead=16.6, space=8, valign='b')
    b.nextpage()

    # ======================================================= 04 tejido
    b.furniture('04')
    opener_block(b, '04', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 12
    x, y, fw, fh = b.fig('tejido_general', fx, Y0 + 2)
    legend(b, [('llegada', GREEN), ('concentración', VIOLET)], fx + 2, y + fh + 8)
    legend(b, [('encuentro', PINK), ('recursos', CYAN)], fx + 50, y + fh + 8)
    b.cap('', 'Dieciséis escenas como hilos sobre once puntos. Marco de trabajo sin escala.', fx + 110, y + fh + 9.5, 150)
    b.nextpage()

    b.furniture('04')
    x, y, fw, fh = b.fig('tejido_cruces', X0, Y0 + 2)
    tx = X0 + fw + 18
    tw = X1 - tx
    b.para('Tres cruces se amplían como problemas espaciales.', tx, Y0 + 6, tw, 60, size=24, lead=27, font='IbI')
    yy = Y0 + 70
    for lab, pair, t in CRUCES_X:
        b.text(lab, tx, yy, 'IbI', 16, PINK)
        b.text(pair, tx + 12, yy - .6, 'Ib', 8.5, GREY)
        h = b.para(t, tx, yy + 4, tw, 40, size=10.4, lead=15.2)
        yy += h + 14
    b.para('Acceso, intimidad, sonido, humedad y luz deciden qué cruces se comparten, cuáles se separan y cuáles cambian de hora.', tx, Y1 - 40, tw, 40, size=10.4, lead=15.2, valign='b', font='IbI')
    b.nextpage()

    b.furniture('04')
    caps = ['09:00 · entrevista y desayuno · S03, S05', '20:30 · comer, acompañar y retirarse · S05, S10, S08', '01:20 · entrega, lavado y descanso · S04, S11, S16']
    for i, n in enumerate(['manana', 'tarde', 'noche']):
        x = X0 + i * 132
        b.fig('tejido_' + n, x, Y0 + 2)
        b.cap('abc'[i], caps[i], x, Y0 + 2 + 90 + 5, 128)
    x, y, fw, fh = b.fig('calibracion', X0, 135)
    tx = X0 + fw + 22
    b.para('Medir con el cuerpo', tx, 140, X1 - tx, 30, size=24, lead=27, font='IbI')
    b.para(['Las mismas posiciones a tres horas del día: la intensidad cambia y nadie ocupa toda la casa a la vez.',
            'Antes de dibujar paredes, el tejido toma tamaño con cuerpos y objetos reales: un tablero A1 que trabaja por su canto corto, un descanso con su anillo de paso y tres cuerpos alrededor de un apoyo.'],
           tx, 155, X1 - tx, 90, size=10.4, lead=15.2, space=7)
    b.cap('d', 'Dibujar, dormir y estar medidos sobre una retícula de 0,25 m. E 1:50', x, y + fh + 5, fw)
    b.nextpage()

    # ======================================================= 05 acciones
    b.furniture('05')
    opener_block(b, '05', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 20
    x, y, fw, fh = b.fig('matriz', fx, Y0 + 4)
    legend(b, [('proximidad', CYAN), ('proteger', PINK), ('por turnos', GOLD), ('condicional', VIOLET)], fx + fw + 14, Y0 + 70, sw='box', gap=6)
    b.cap('', 'Gris: relación no definida.', fx + fw + 14, Y0 + 70 + 4 * 6 + 4, 40)
    b.nextpage()

    b.furniture('05')
    REL = json.load(open('/home/claude/g3/w/G3_TEJIDO_REGLAS_Y_ALTERNATIVAS_2026-10-18/RELACIONES.json'))
    ACC = {a['id']: a['accion'] for a in json.load(open('/home/claude/g3/w/G3_TEJIDO_REGLAS_Y_ALTERNATIVAS_2026-10-18/ACCIONES.json'))}
    tcol = {'PROXIMIDAD': CYAN, 'PROTEGER': PINK, 'POR_TURNOS': GOLD, 'CONDICIONAL': VIOLET}
    tname = {'PROXIMIDAD': 'proximidad', 'PROTEGER': 'proteger', 'POR_TURNOS': 'por turnos', 'CONDICIONAL': 'condicional'}
    b.para('Cada relación tiene una razón y una escena de partida.', X0, Y0 + 8, 300, 30, size=24, lead=27, font='IbI')
    colw = (X1 - X0 - 24) / 2
    for i, r in enumerate(REL):
        col, row = i // 14, i % 14
        x = X0 + col * (colw + 24)
        y = Y0 + 34 + row * 16.2
        b.c.setFillColor(tcol[r['tipo']])
        b.c.circle((x + 1.3) * mm, (H - y + 1.2) * mm, 1.3 * mm, stroke=0, fill=1)
        b.text(f"{ACC[r['a']]} × {ACC[r['b']].lower()}", x + 5, y + 2.2, 'IbI', 11, INK)
        b.text(f"{tname[r['tipo']]} · {r['escena']}", x + colw, y + 2.2, 'IbI', 8, GREY, anchor='r')
        b.para(r['razon'], x + 5, y + 4.6, colw - 5, 10, size=9.4, lead=12)
    b.nextpage()

    b.furniture('05')
    for i in range(3):
        x = X0 + i * 132
        b.fig(f'tejido_reglas_{i + 1}', x, Y0 + 2)
        b.cap('abc'[i], f'Tejido {i + 1}', x, Y0 + 2 + 92 + 5, 120)
    ty = Y0 + 2 + 92 + 20
    b.para('Tres maneras de ordenar las mismas relaciones', X0, ty, 160, 40, size=24, lead=27, font='IbI')
    b.para(['Las veinte acciones se mueven libres sobre una retícula de 13 × 9 posiciones con dos reglas: lo que pide proximidad, a tres pasos como mucho; lo que pide protección, a cinco como poco.',
            'De dieciocho búsquedas se eligen tres colocaciones que cumplen las dos reglas sin excepción y que se parecen lo menos posible entre sí. Ninguna es una planta: son el paso entre las relaciones y la casa.'],
           X0, ty + 30, 160, 100, size=10.4, lead=15.2, space=7)
    legend(b, [('proximidad', CYAN), ('proteger', PINK)], X0 + 180, ty + 4)
    legend(b, [('por turnos', GOLD), ('condicional', VIOLET)], X0 + 180, ty + 13)
    # clave de acciones
    kx = X0 + 240
    keys = list(ACC.items())
    for i, (k, v) in enumerate(keys):
        col, row = i // 10, i % 10
        xx = kx + col * 76
        yy = ty + 2 + row * 6.4
        b.text(k[1:], xx, yy + 2, 'Ib', 8, PINK)
        b.text(v, xx + 7, yy + 2, 'IbI', 9, INK)
    b.nextpage()

    # ======================================================= 06 habitación
    b.furniture('06')
    opener_block(b, '06', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 30
    for i, n in enumerate(['habitacion_abierta', 'habitacion_recogida']):
        x, y, fw, fh = b.fig(n, fx + i * 136, Y0 + 40)
        b.cap('ab'[i], ['Tablero abierto. E 1:50', 'Tablero recogido. E 1:50'][i], x, y + fh + 6, 110)
    b.nextpage()
    b.furniture('06')
    x, y, fw, fh = b.fig('vestidor', X0, Y0 + 30)
    b.cap('a', 'Vestidor: 0,55 m de ropa alrededor de un hueco libre de 0,90 m de radio. E 1:25', x, y + fh + 6, fw)
    x, y, fw, fh = b.fig('bow_planta', X0 + 110, Y0 + 30)
    b.cap('b', 'Bow: vidrio curvo de 1,25 m de radio que vuela 0,60 m de la fachada, y un asiento curvo de 0,57 m de fondo. E 1:20', x, y + fh + 6, fw)
    b.para('La bow es pequeña a propósito: un sitio para una persona, con la espalda en la habitación y la cara en la calle.', X0 + 110, y + fh + 30, 150, 60, size=18, lead=21, font='IbI')
    x, y, fw, fh = b.fig('bow_seccion', X1 - 88, Y0 + 30)
    b.cap('c', 'Sección por la bow: asiento a 0,46 m, antepecho a 0,80 m y la tela por delante del vidrio. E 1:25', x, y + fh + 6, fw)
    b.nextpage()

    # ======================================================= 07 servicios
    b.furniture('07')
    opener_block(b, '07', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 24
    x, y, fw, fh = b.fig('servicios_detalle', fx, Y0 + 20, X1 - fx, 220, align='c')
    b.cap('', 'Las visuales desde el estar hacia las puertas de los aseos se detienen en el filtro. E 1:30', x, y + fh + 6, fw)
    b.nextpage()

    # ======================================================= 08 tres casas
    b.furniture('08')
    opener_block(b, '08', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 18
    names = {'V01_U': 'V01 · Convivencia continua', 'V02_U': 'V02 · Dos ámbitos', 'V03_U': 'V03 · Centro libre'}
    for i, c in enumerate(['V01_U', 'V02_U', 'V03_U']):
        x, y, fw, fh = b.fig('comparar_' + c, fx + i * 94, Y0 + 60)
        b.cap('abc'[i], names[c], x, y + fh + 6, fw)
    b.text('Misma habitación, misma pieza de servicios, misma escala. E 1:220', fx, Y0 + 60 + 87 + 20, 'IbI', 8, GREY)
    plant_legend(b, fx, Y0 + 60 + 87 + 34)
    b.nextpage()

    def unit_page(code, chap, opener=False):
        u = UNIDADES[code]
        d = INFO[code]
        if not opener:
            b.furniture(chap)
        fw0, fh0 = fsize('planta_' + code)
        area_w = X1 - X0
        colw = max(110, min(150, area_w - fw0 - 18))
        if opener:
            colw = 0
        tx = X1 - colw
        if not opener:
            x, y, fw, fh = b.fig('planta_' + code, X0, Y0 + 4, tx - 18 - X0, Y1 - Y0 - 14, align='c', valign='c')
            b.cap('', f"Planta. E 1:{d['escala']}", x, y + fh + 4, 80)
            yy = Y0 + 2
            b.para(u['t'], tx, yy, colw, 40, size=34, lead=35, font='IbI')
            yy += b.measure(u['t'], colw, 34, 35, 'IbI') + 4
            b.text(u['sub'], tx, yy + 3, 'IbI', 12, INK)
            yy += 10
            h = b.para(u['x'], tx, yy, colw, 120, size=10.4, lead=15.2, space=6)
            yy += h + 6
            s_ = f"{d['suelo_m2']:.2f}".replace('.', ',')
            e_ = f"{d['envolvente_estudio_m2']:.2f}".replace('.', ',')
            b.text(f"{s_} m² de suelo · {e_} m² de envolvente", tx, yy + 2, 'IbI', 9, INK)
            # lectura relacional en la parte baja de la columna
            lw, lh = fsize('lectura_' + code)
            ly = Y1 - 26 - lh
            b.fig('lectura_' + code, tx, ly)
            b.cap('', LECTURA + f" E&nbsp;1:{250 if code.endswith('_U') else 330}", tx, ly + lh + 5, colw)
        b.nextpage()

    for c in ['V01_U', 'V02_U', 'V03_U']:
        unit_page(c, '08')

    # ======================================================= 09 casas de ocho
    b.furniture('09')
    opener_block(b, '09', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    fx = X0 + 96 + 24
    x, y, fw, fh = b.fig('planta_V02_P', fx, Y0 + 4, X1 - fx, 140, align='c')
    b.cap('', 'Planta. E 1:150', x, y + fh + 4, 80)
    u = UNIDADES['V02_P']
    d = INFO['V02_P']
    ty = Y0 + 4 + fh + 18
    b.para(u['t'], fx, ty, 120, 30, size=30, lead=31, font='IbI')
    b.text(u['sub'], fx, ty + 16, 'IbI', 12, INK)
    b.para(u['x'], fx, ty + 24, 130, 100, size=10.4, lead=15.2, space=6)
    s_ = f"{d['suelo_m2']:.2f}".replace('.', ',')
    e_ = f"{d['envolvente_estudio_m2']:.2f}".replace('.', ',')
    b.text(f"{s_} m² de suelo · {e_} m² de envolvente", fx, Y1 - 2, 'IbI', 9, INK)
    lw, lh = fsize('lectura_V02_P')
    b.fig('lectura_V02_P', X1 - lw, Y1 - 20 - lh)
    b.cap('', LECTURA + ' E&nbsp;1:330', X1 - 130, Y1 - 20 + 5, 130)
    b.nextpage()
    for c in ['V01_D', 'V01_S', 'V03_D', 'V03_S']:
        unit_page(c, '09')

    # ======================================================= 10 superficies
    b.furniture('10')
    opener_block(b, '10', X0, Y0 + 2, 96, Y1 - Y0 - 2)
    tx = X0 + 96 + 24
    order = ['V01_U', 'V02_U', 'V03_U', 'V02_P', 'V01_D', 'V01_S', 'V03_D', 'V03_S']
    cols = [('organización', 0), ('residentes', 92), ('suelo m²', 126), ('envolvente m²', 160), ('aseos', 200)]
    y = Y0 + 8
    for lab, dx in cols:
        b.text(lab, tx + dx, y, 'IbI', 9, GREY, anchor='l' if dx == 0 else 'l')
    b.c.setStrokeColor(INK)
    b.c.setLineWidth(.4)
    b.c.line(tx * mm, (H - y - 3) * mm, (tx + 215) * mm, (H - y - 3) * mm)
    for i, c in enumerate(order):
        d = INFO[c]
        yy = y + 11 + i * 9
        b.text(UNIDADES[c]['t'], tx, yy, 'IbI', 12, INK)
        b.text(c.replace('_', ' '), tx + 56, yy, 'Ib', 8, GREY)
        b.text(str(d['habitantes']), tx + 92, yy, 'Ib', 11, INK)
        b.text(f"{d['suelo_m2']:.2f}".replace('.', ','), tx + 126, yy, 'Ib', 11, INK)
        b.text(f"{d['envolvente_estudio_m2']:.2f}".replace('.', ','), tx + 160, yy, 'Ib', 11, INK)
        b.text(str(d['banos']), tx + 200, yy, 'Ib', 11, INK)
        if i == 2:
            b.c.setStrokeColor(HexColor('#D9D9D9'))
            b.c.line(tx * mm, (H - yy - 3.5) * mm, (tx + 215) * mm, (H - yy - 3.5) * mm)
    x, y2, fw, fh = b.fig('superficie_persona', tx - 4, Y0 + 104)
    sx = tx + 215 + 6
    b.para(['Por persona, la casa común continua se queda en 36,8 m², casi lo mismo que una casa de cuatro; la plaza entre estancias llega a 41,9.',
            'Para cuarenta residentes hacen falta cinco grupos de ocho. Con la casa común continua la envolvente suma 1.471 m², dentro de los 1.500 m² del enunciado pero con poco margen para escaleras, zócalo y estructura. Con la plaza entre estancias, 1.677 m².'],
           sx, Y0 + 8, X1 - sx, 200, size=10.4, lead=15.2, space=7)
    b.cap('', 'Suelo geométrico: incluye las huellas de las divisiones; no es superficie útil. Envolvente: el suelo expandido 12 cm.', tx, Y1 - 4, 215)
    b.nextpage()

    # ======================================================= lo privado y lo común
    b.furniture()
    b.para('Lo privado y lo común', X0, Y0 + 8, 300, 30, size=46, lead=48, font='IbI')
    row = ['V01_U', 'V02_U', 'V03_U', 'V01_S', 'V03_S']
    ws = [fsize('lectura_' + c) for c in row]
    gx = (X1 - X0 - sum(w for w, _ in ws)) / (len(row) - 1)
    x = X0
    for i, (c, (w, h)) in enumerate(zip(row, ws)):
        b.fig('lectura_' + c, x, 128 - h)
        b.cap('abcde'[i], UNIDADES[c]['t'] + (' · E&nbsp;1:250' if c.endswith('_U') else ' · E&nbsp;1:330'), x, 134, w + 20)
        x += w + gx
    colw = (X1 - X0 - 2 * 18) / 3
    for i, (t, x_) in enumerate(PRIVADO_COMUN):
        col, row = i % 3, i // 3
        xx = X0 + col * (colw + 18)
        yy = 158 + row * 56
        b.para(t, xx, yy, colw, 20, size=20, lead=22, font='IbI')
        b.para(x_, xx, yy + 12, colw, 60, size=11.4, lead=16.6)
    b.nextpage()

    # ======================================================= cierre
    b.furniture()
    b.para(CIERRE, X0, Y0 + 8, 330, 100, size=40, lead=44, font='IbI')
    b.para(COLOFON, X0, 214, 150, 70, size=8.4, lead=12, space=3)
    fw, fh = fsize('planta_V01_S')
    b.fig('planta_V01_S', X1 - fw, Y1 - fh + 4)
    b.nextpage()
    b.save()

    # ---- índice: segundo pase dibujando sobre la página 3
    return b, idx_page


def draw_index(path_in, b, idx_page):
    from reportlab.pdfgen import canvas as cv
    tmp = OUT / '_indice.pdf'
    c = cv.Canvas(str(tmp), pagesize=(W * mm, H * mm))
    def t(txt, x, y, font, size, col=INK, anchor='l'):
        c.setFillColor(col)
        c.setFont(font, size)
        {'l': c.drawString, 'r': c.drawRightString}[anchor](x * mm, (H - y) * mm, txt)
    t('Índice', X0, Y0 + 30, 'IbI', 46)
    for i, n in enumerate(sorted(CAP)):
        col, row = i // 5, i % 5
        x = X0 + 130 + col * 140
        y = Y0 + 70 + row * 34
        t(n, x, y, 'Ib', 40)
        t(CAP[n]['t'], x + 30, y - 9, 'IbI', 17)
        t(CAP[n]['lema'], x + 30, y - 2, 'IbI', 9, GREY)
        t(str(b.toc[n]), x + 128, y - 9, 'IbI', 11, anchor='r')
    c.showPage()
    c.save()
    pdf = pikepdf.open(path_in)
    ov = pikepdf.open(tmp)
    pdf.pages[idx_page - 1].add_overlay(ov.pages[0])
    return pdf


def place_figures(pdf, b):
    cache = {}
    for (pi, name, x, y, w, h) in b.figs:
        if name not in cache:
            cache[name] = pikepdf.open(FIG / (name + '.pdf'))
        src = cache[name].pages[0]
        page = pdf.pages[pi]
        llx, lly = x * mm, (H - y - h) * mm
        page.add_overlay(src, pikepdf.Rectangle(llx, lly, llx + w * mm, lly + h * mm))
    return pdf


if __name__ == '__main__':
    b, idx = build()
    pdf = draw_index(b.path, b, idx)
    pdf = place_figures(pdf, b)
    final = OUT / 'G3_CENTROS_PARA_CONVIVIR_A3.pdf'
    pdf.save(final)
    print('paginas', len(pdf.pages), final)
