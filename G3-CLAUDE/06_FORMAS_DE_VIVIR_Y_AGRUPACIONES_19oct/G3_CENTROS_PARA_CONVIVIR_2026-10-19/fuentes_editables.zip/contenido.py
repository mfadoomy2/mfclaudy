# -*- coding: utf-8 -*-
# Textos del cuaderno. Tono de resultado: presente, sin lenguaje de revisión.
import json

PORTADA = {
    'l1': 'Centros',
    'l2': 'para convivir',
    'sub': 'Vivienda temporal para jóvenes en Ribera de Curtidores 31',
    'pie1': 'Cuaderno de plantas',
    'pie2': 'G3 Proyectos · Universidad Europea de Madrid · Octubre 2026',
}

CITA_INTRO = 'Llegar, cocinar, acompañar, retirarse, volver.'

INTRO = [
    'Este cuaderno recoge cómo se organiza una casa para cuatro, y para ocho, personas jóvenes que comparten vivienda durante un tiempo en El Rastro. No empieza por una forma. Empieza por lo que pasa dentro: volver empapadas de madrugada, una entrevista por videollamada mientras otra cocina, alguien que necesita dormir porque entra a trabajar a las seis.',
    'De esas escenas salen relaciones: cosas que conviene acercar, cosas que hay que proteger unas de otras y cosas que pueden compartir el mismo sitio por turnos. Las relaciones se ordenan primero en un tejido sin metros y después se miden con cuerpos, muebles y pasos reales.',
    'Una regla ordena todas las plantas: el centro de la casa es para convivir. Los aseos se agrupan en el borde, detrás de un vestíbulo y un filtro, y el suelo que queda en medio se reserva para cocinar, comer, hablar y estar.',
    'Salen tres casas de cuatro —una continua, una en dos ámbitos, una con el centro libre— y cinco maneras de unirlas en grupos de ocho. Cada residente tiene su habitación, con un vestidor que se recorre, un tablero A1 que se recoge contra la pared y una bow pequeña donde sentarse a mirar fuera.',
]

CAP = {
    '01': {'t': 'Dieciséis escenas', 'lema': 'Una casa compartida, hora a hora.',
           'x': 'Antes de dibujar una pared, la casa se pone a prueba con dieciséis escenas inventadas. No son entrevistas ni estadísticas: son situaciones que reconoce cualquiera que haya compartido piso, escritas para que choquen entre sí. Cada una dice qué pasa, qué secuencia de acciones arrastra y qué necesita del espacio. La última línea es la crítica: lo que la casa no debería obligar a hacer a nadie.'},
    '02': {'t': 'Acercar y proteger', 'lema': 'Cinco atractores y los cruces entre ellos.',
           'x': 'Las escenas se agrupan alrededor de cinco atractores: estar y cocinar; retirarse y concentrarse; acompañar y conversar; dibujar y reparar; lavar, guardar y mantener. Entre ellos hay dos tipos de relación. Las turquesas son proximidades útiles, siempre con condiciones. Las rosas son conflictos que piden separar en el espacio o en el horario. Las distancias del dibujo no son metros: un atractor puede estar en varios sitios y cambiar con la hora.'},
    '03': {'t': 'La parcela', 'lema': '651 m² entre medianeras, abiertos a Ribera de Curtidores.',
           'x': 'La parcela catastral 0134911VK4703C da a Ribera de Curtidores por un frente de quince metros y se alarga casi cincuenta hacia el interior de la manzana, entre edificios de alturas muy distintas. Es el suelo real del proyecto: estrecho, profundo y rodeado. Los grises del plano indican el número de plantas de cada edificio vecino; cuanto más oscuro, más alto.'},
    '04': {'t': 'Un tejido de cosas que pasan', 'lema': 'Puntos que son acciones, hilos que son secuencias.',
           'x': 'Sobre un marco de trabajo sin escala, once puntos recogen lo que se hace en la casa: llegar, mojarse y secarse, estar acompañadas, preparar comida, hablar en confianza, desplegar y reparar, guardar, y cuatro lugares de retiro. Cada escena se dibuja como un hilo que los recorre en orden. Las manchas son ámbitos de uso, no habitaciones. Donde los hilos se amontonan, la casa tiene que decidir.'},
    '05': {'t': 'Veinte acciones', 'lema': 'Acercar, proteger, compartir por turnos.',
           'x': 'Las acciones se separan de los lugares. Veinte acciones, desde dormir hasta guardar herramientas, y veintiocho relaciones razonadas entre ellas: doce piden proximidad, ocho piden protección, cuatro pueden compartir sitio por turnos y cuatro dependen de condiciones. Lo que queda en gris no está decidido, y por eso no se da por compatible.'},
    '06': {'t': 'La habitación', 'lema': '18,35 m² para dormir, vestirse, trabajar y mirar fuera.',
           'x': 'Cada residente tiene su habitación. La cama de 1,25 × 2,00 m queda a un lado y deja libre el eje de la puerta. El tablero de 1,80 × 0,90 m gira sobre su canto corto: abierto es una mesa para trabajar un A1; recogido, deja el suelo libre. El vestidor es una media luna que se recorre por dentro, y al fondo la bow abre la habitación hacia fuera con un asiento que sigue la curva del vidrio.'},
    '07': {'t': 'Servicios en el borde', 'lema': 'Dos aseos, un vestíbulo y un filtro.',
           'x': 'Ningún aseo ocupa el centro de la casa. Los dos aseos de cada casa de cuatro se agrupan en una pieza de servicio pegada al perímetro, con su propia fachada. Se entra por un paso de 1,30 m a un vestíbulo; un tabique exento corta la visual desde el estar hacia las puertas, y el paso lo rodea con holgura para un giro de 90 cm. El centro queda para cocinar, comer y estar, y quien quiere ducharse y acostarse no tiene que cruzar la reunión.'},
    '08': {'t': 'Tres casas de cuatro', 'lema': 'Continua, en dos ámbitos, con el centro libre.',
           'x': 'Con la misma habitación y la misma pieza de servicios salen tres maneras distintas de convivir. En la primera, cocinar, comer y estar se enlazan en un solo espacio. En la segunda, la casa se divide en dos ámbitos conectados. En la tercera, el estar ocupa un círculo libre y las habitaciones lo rodean. Ninguna es un giro de otra.'},
    '09': {'t': 'Casas de ocho', 'lema': 'Cinco maneras de juntar dos casas.',
           'x': 'Dos casas de cuatro pueden juntarse de muchas maneras, y cada una dice algo distinto sobre cómo se vive en grupo. La pareja con umbral conserva dos cocinas y dos mesas y comparte solo un lugar de encuentro. Las uniones de la V01 convierten el encuentro en la casa: una sala mayor o un suelo continuo para ocho. Las de la V03 ensayan una plaza entre dos círculos o una estancia en diagonal. En todas, cada persona llega a su habitación sin atravesar la de nadie y los aseos siguen en el borde.'},
    '10': {'t': 'Superficies', 'lema': 'Lo que cuesta cada manera de convivir.',
           'x': 'Cada decisión de convivencia tiene un precio en suelo. Las tres casas de cuatro ocupan entre 132 y 138 m²; las de ocho, entre 274 y 310 m². Los vestíbulos de servicio y los encuentros se pagan en superficie: entre la unión más compacta y la más expansiva hay 36 m² por grupo.'},
}

SIT = json.load(open('/home/claude/g3/w/G3_MAPA_ACTIVIDADES_PARCELA_2026-10-18/SITUACIONES.json'))

CRUCES = [
    ('S01 × S16', 'Secar y ducharse / dormir enferma', 'Separar ruido y humedad; ayuda cerca, sin exposición.'),
    ('S03 × S05', 'Entrevista / cocinar para varias', 'Conexión privada y separación acústica, sin prohibir cocinar.'),
    ('S04 × S08', 'Entrega nocturna / derecho al retiro', 'Un trabajo que pueda quedarse montado, fuera del acceso.'),
    ('S02 × S13', 'Acoger una noche / intimidad', 'Un lugar temporal acordado, sin ocupar el dormitorio de otra.'),
    ('S07 × S15', 'Reparar / llegar con cargas', 'Herramientas cerca, material fuera del recorrido.'),
    ('S10 × S06', 'Acompañar / mediar un conflicto', 'El mismo lugar puede servir por turnos si hay confidencialidad.'),
    ('S11 × S09', 'Lavar tarde / salir temprano', 'Capacidad, almacenamiento, separación acústica y horarios.'),
    ('S12 × S03', 'Cerrar la tela por calor / trabajar', 'Controlar clima y luz a la vez; la tela no está siempre abierta.'),
]

CRUCES_X = [
    ('X1', 'S03 × S05', 'Hablar en privado mientras otras cocinan. Una entrevista no puede depender de que nadie use la cocina.'),
    ('X2', 'S04 × S08', 'Dejar el trabajo montado y poder retirarse. La entrega nocturna necesita un sitio fuera del paso.'),
    ('X3', 'S07 × S15', 'Reparar sin ocupar la llegada. Las herramientas cerca, el material fuera del recorrido.'),
]

SOL = {
    'x': ['El sol directo depende de la altura. El 21 de diciembre, a cota de calle, la parcela recibe de media 0,2 horas de sol; a 19,5 m, 1,7 horas; a 25,7 m, 8,5. En marzo pasa de 0,9 a 12 horas, y en junio, de 8 a 14,7.',
          'Por debajo de los dieciséis metros, el invierno es casi de sombra. Las casas necesitan subir para encontrar luz; lo que se queda abajo tiene que ser lo que puede vivir sin sol directo.'],
    'cap': 'Horas medias de sol directo sobre la parcela a distintas alturas. Modelo 2,5D con las alturas de los edificios vecinos estimadas por su número de plantas.',
}

UNIDADES = {
    'V01_U': {'t': 'Convivencia continua', 'sub': 'V01 · cuatro residentes',
              'x': ['Una sola sala alargada reúne cocina, mesa y estar. Las cuatro habitaciones se abren a ella por parejas, enfrentadas, y las bow miran hacia fuera.',
                    'Preparar y comer quedan juntos sin pasar por ningún dormitorio; el estar se va al otro extremo, junto a la entrada. Los aseos ocupan el extremo opuesto, detrás de su vestíbulo, y la mesa se coloca de través para dejar paso alrededor de sus cuatro sillas.']},
    'V02_U': {'t': 'Dos ámbitos', 'sub': 'V02 · cuatro residentes',
              'x': ['La casa se parte en dos ámbitos desplazados, unidos por un paso. En uno se prepara la comida; en el otro se come y se está. Nadie está obligado a participar de lo que pasa al otro lado.',
                    'Los aseos salen de los dos focos y se concentran en el borde, con un filtro que no se confunde con el paso entre ámbitos.']},
    'V03_U': {'t': 'Centro libre', 'sub': 'V03 · cuatro residentes',
              'x': ['El estar recupera el centro: un círculo de 3,25 m de radio con la mesa, el sofá y la cocina, sin ningún servicio dentro. Las cuatro habitaciones se colocan en cruz alrededor y se enlazan con él mediante pequeños ensanchamientos rectos.',
                    'Los aseos se llevan a una pieza de servicio en el borde, unida al círculo por un brazo en diagonal que deja las bow siempre hacia fuera. Es la más generosa en el centro y la que más recorrido pide.']},
    'V02_P': {'t': 'Pareja con umbral', 'sub': 'V02 · ocho residentes',
              'x': ['Dos casas conservan sus espacios compartidos —dos cocinas, dos comedores de cuatro— y se encuentran en un umbral común, un pequeño círculo con su propia entrada.',
                    'Es la unión con más autonomía entre grupos. El encuentro no lleva ningún servicio en su centro: los aseos quedan en los extremos exteriores.']},
    'V01_D': {'t': 'Encuentro mayor', 'sub': 'V01 · ocho residentes',
              'x': ['El encuentro se convierte en una sala para ocho. Recibir, comer y reunirse ocurren desde una llegada común, con una mesa grande para todas.',
                    'Hay una cocina principal, una despensa, una mesa de trabajo y un estar. Los cuatro aseos se reparten entre los dos bordes filtrados y los ocho dormitorios siguen siendo individuales.']},
    'V01_S': {'t': 'Casa común continua', 'sub': 'V01 · ocho residentes',
              'x': ['Un suelo común continuo enlaza cocina, trabajo, comida y estar sin ninguna puerta entre las dos casas de origen. La mesa admite a las ocho.',
                    'Dos dormitorios se desplazan 0,90 m para liberar la llegada y el paso alrededor de la mesa, sin reducir cuerpos ni muebles. Los servicios quedan en los dos extremos.']},
    'V03_D': {'t': 'Plaza entre estancias', 'sub': 'V03 · ocho residentes',
              'x': ['Una plaza circular de 3,05 m de radio pone en relación los dos círculos libres. Las dos cocinas pertenecen al grupo de ocho y la mesa común se coloca en diagonal en mitad de la plaza.',
                    'Los servicios se apartan al borde exterior de cada extremo. Es la unión de mayor intensidad formal y también la de mayor superficie.']},
    'V03_S': {'t': 'Continuidad diagonal', 'sub': 'V03 · ocho residentes',
              'x': ['La convivencia se prolonga por un interior en diagonal de 4,50 m de ancho entre los dos círculos, sin aseos en su centro. La mesa de ocho queda en mitad de la continuidad.',
                    'El tramo se ensancha lo necesario para rodear la mesa. Es una unión larga, que atraviesa la casa de un extremo a otro.']},
}

LECTURA = 'Lectura de la planta. Turquesa: preparar, comer y estar, cerca. Rosa: lo que el estar no debe invadir.'

PRIVADO_COMUN = [
    ('Lo privado', 'Dormir, vestirse, guardar la ropa, trabajar en el tablero y retirarse en la bow. La cama nunca ocupa el eje de la puerta.'),
    ('Lo compartido', 'Preparar comida, comer, conversar, recibir y limpiar. El vestíbulo de los aseos es una transición de servicio, no una estancia.'),
    ('Dos grupos', 'En la pareja con umbral, cada casa conserva su cocina y su mesa; el umbral es el único lugar de las ocho.'),
    ('Un grupo', 'En el encuentro mayor y en la casa común continua, la llegada, la comida, el trabajo y la estancia pertenecen a las ocho, y nadie atraviesa otra habitación para llegar a la suya.'),
    ('Dos centros', 'En la plaza y en la diagonal, el centro de cada ámbito vuelve a ser habitable. Las dos cocinas pueden formar dos subgrupos dentro del grupo, y eso también es una manera de convivir.'),
    ('Acuerdos', 'Compartir requiere acuerdos de uso, de cuidado y de retirada. Una planta abierta no los garantiza, ni obliga a estar siempre en grupo.'),
]

CIERRE = 'Tres casas de cuatro y cinco maneras de juntarlas. El siguiente paso es llevarlas a la parcela, compactar los servicios sin devolverlos al centro y probar la luz en sección.'

COLOFON = [
    'G3 Proyectos · Vivienda temporal para jóvenes en El Rastro · Universidad Europea de Madrid · Octubre 2026.',
    'Las escenas son inventadas para el proyecto. Parcela: Catastro, referencia 0134911VK4703C. Sol: modelo 2,5D con alturas vecinas estimadas por número de plantas.',
    'Plantas dibujadas en metros desde la geometría del proyecto. Suelo geométrico: incluye las huellas de las divisiones; no es superficie útil. Envolvente: el suelo expandido 12 cm.',
    'Tipografía: Ibarra Real Nova.',
]
