# -*- coding: utf-8 -*-
# Diagramas de investigación redibujados desde sus datos originales.
import sys, json, math, textwrap
sys.path.insert(0, '/home/claude/g3/build')
from estilo import *
import numpy as np
from matplotlib.patches import Circle, Ellipse, Rectangle, Polygon, PathPatch, FancyArrowPatch
from matplotlib.path import Path as MPath
from shapely.geometry import shape, Point
from shapely.affinity import translate

W = Path('/home/claude/g3/w')
D = W / 'INVESTIGACIÓN/00_INVESTIGACION_COMPLETA/DATOS/DERIVADOS'
SIT = json.load(open(W / 'G3_MAPA_ACTIVIDADES_PARCELA_2026-10-18/SITUACIONES.json'))
NR = json.load(open(W / 'G3_UNIDAD_TEJIDO_ACTIVIDADES_2026-10-18/NODOS_Y_RECORRIDOS.json'))
ACC = json.load(open(W / 'G3_TEJIDO_REGLAS_Y_ALTERNATIVAS_2026-10-18/ACCIONES.json'))
REL = json.load(open(W / 'G3_TEJIDO_REGLAS_Y_ALTERNATIVAS_2026-10-18/RELACIONES.json'))
RES = json.load(open(W / 'G3_TEJIDO_REGLAS_Y_ALTERNATIVAS_2026-10-18/RESULTADOS.json'))


def axes_mm(wmm, hmm, xlim, ylim, equal=True):
    fig = plain(wmm, hmm)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    if equal:
        ax.set_aspect('equal', adjustable='datalim')
    ax.axis('off')
    ax.patch.set_alpha(0)
    return fig, ax


# ------------------------------------------------------------ red de atractores
pos = {'encuentro': (0, 2.9), 'descanso': (-4, -.8), 'cuidado': (4, -.8), 'hacer': (-3.8, -3.6), 'recursos': (3.8, -3.6)}
labels = {'encuentro': 'estar\ncocinar', 'descanso': 'retirarse\nconcentrarse', 'cuidado': 'acompañar\nconversar', 'hacer': 'dibujar\nreparar', 'recursos': 'lavar, guardar\nmantener'}
links = [('encuentro', 'descanso', 'separar ruido,\npermitir retiro', PINK), ('encuentro', 'cuidado', 'cercanía con\nconfidencialidad', CYAN),
         ('descanso', 'hacer', 'separar el corte,\nconservar el trabajo', PINK), ('hacer', 'recursos', 'herramientas y\nalmacenamiento', CYAN),
         ('cuidado', 'recursos', 'tareas y\nresponsabilidades', CYAN), ('encuentro', 'recursos', 'cocinar, limpiar,\nrepartir', CYAN)]
fig, ax = axes_mm(270, 194, (-6.6, 6.6), (-5.0, 4.4))
R = .95
for u, v, t, c in links:
    (x, y), (X, Y) = pos[u], pos[v]
    d = math.hypot(X - x, Y - y)
    ux, uy = (X - x) / d, (Y - y) / d
    ax.plot([x + ux * R, X - ux * R], [y + uy * R, Y - uy * R], color=c, lw=1.6, solid_capstyle='round')
    mx, my = (x + X) / 2, (y + Y) / 2
    off = {('encuentro', 'recursos'): (-.35, -1.25), ('cuidado', 'recursos'): (1.15, 0), ('descanso', 'hacer'): (-1.55, 0)}.get((u, v), (0, 0))
    ax.text(mx + off[0], my + off[1], t, fontsize=9.5, fontstyle='italic', color=INK, ha='center', va='center', linespacing=1.15,
            bbox=dict(fc='white', ec='none', pad=1.8))
for k, (x, y) in pos.items():
    ax.add_patch(Circle((x, y), R, fc='white', ec=INK, lw=.8, zorder=4))
    ax.text(x, y + .12, labels[k], ha='center', va='center', fontsize=11, color=INK, zorder=5, linespacing=1.15)
    ids = [s['id'] for s in SIT if s['atractor'] == k]
    idt = ' · '.join(ids)
    if len(ids) > 3:
        idt = ' · '.join(ids[:3]) + '\n' + ' · '.join(ids[3:])
    it(ax, x, y - .58, idt, 7.5, color=GREY, zorder=5, linespacing=1.1)
save(fig, 'red_atractores')

# ------------------------------------------------------------ parcela 1:500
parcel = shape(json.load(open(D / 'parcela_31.geojson'))['features'][0]['geometry'])
ox, oy = 439984, 4473229.4
parcel = translate(parcel, -ox, -oy)
xmin, xmax, ymin, ymax = 0, 78, -36, 36
fig, ax = scaled(xmin, xmax, ymin, ymax, 400)
parts = json.load(open(D / 'catastro_partes_400m.geojson'))['features']
bounds = parcel.buffer(60)
from shapely.geometry import box as sbox
clip = sbox(xmin, ymin + 5, xmax, ymax)
for feature in parts:
    g = translate(shape(feature['geometry']), -ox, -oy)
    if not g.intersects(bounds):
        continue
    g = g.intersection(clip)
    if g.is_empty:
        continue
    n = feature['properties'].get('plantas_sr')
    col = '#EDEDED' if not n else plt.cm.Greys(.12 + min(n, 10) * .06)
    for q in ([g] if g.geom_type == 'Polygon' else [p for p in getattr(g, 'geoms', []) if p.geom_type == 'Polygon']):
        ax.add_patch(Polygon(np.array(q.exterior.coords), fc=col, ec='white', lw=.3))
ax.add_patch(Polygon(np.array(parcel.exterior.coords), fc='#F6CFE1', ec=PINK, lw=1.4, zorder=5))
co = list(parcel.exterior.coords)
ax.plot(*zip(*[co[16], co[17]]), color=PINK, lw=3.2, zorder=6, solid_capstyle='butt')
it(ax, 1.0, 0.2, 'Ribera de\nCurtidores', 8, ha='left')
c = parcel.centroid
it(ax, c.x + 4, c.y - 1.2, '651 m²', 9, zorder=7)
# norte
ax.add_patch(FancyArrowPatch((73, 24), (73, 31), arrowstyle='-|>', mutation_scale=8, color=INK, lw=.8))
rm(ax, 73, 33, 'N', 8)
ax.plot([1, 21], [-34, -34], color=INK, lw=.8)
for t in range(0, 21, 5):
    ax.plot([1 + t, 1 + t], [-34, -34 + (.8 if t in (0, 20) else .5)], color=INK, lw=.5)
it(ax, 22.5, -33.9, '20 m', 7, ha='left')
save(fig, 'parcela')

# ------------------------------------------------------------ sol por altura
sun = json.load(open(D / 'sol_por_altura.json'))
fig = plain(250, 175)
ax = fig.add_axes([.09, .11, .80, .86])
for date, cc, lab in [('2026-12-21', PINK, '21 de diciembre'), ('2026-03-21', CYAN, '21 de marzo'), ('2026-06-21', GOLD, '21 de junio')]:
    vals = sorted((float(z), v['media']) for z, v in sun[date].items())
    ax.plot([v[1] for v in vals], [v[0] for v in vals], '-o', c=cc, lw=1.3, ms=3.5, mec='white', mew=.6)
    ax.text(vals[-1][1] + .25, vals[-1][0], lab, color=INK, fontsize=9.5, fontstyle='italic', va='center', ha='left')
for s in ['top', 'right']:
    ax.spines[s].set_visible(False)
for s in ['left', 'bottom']:
    ax.spines[s].set_color(INK)
    ax.spines[s].set_linewidth(.5)
ax.set_xlim(0, 17.5)
ax.set_ylim(-1, 28)
ax.set_xticks(range(0, 17, 2))
ax.set_yticks([0, 5, 10, 15, 20, 25])
ax.tick_params(labelsize=9, colors=INK, width=.5, length=3)
ax.grid(color=LIGHT, lw=.4)
ax.set_xlabel('horas medias de sol directo', fontsize=9.5, fontstyle='italic', color=INK)
ax.set_ylabel('altura sobre la calle, m', fontsize=9.5, fontstyle='italic', color=INK)
ax.patch.set_alpha(0)
save(fig, 'sol_altura')

# ------------------------------------------------------------ tejido de actividades
nodes = {k: tuple(v) for k, v in NR['positions'].items()}
tlabels = NR['labels']
routes = NR['routes']
tcol = {'llegada': GREEN, 'concentracion': VIOLET, 'encuentro': PINK, 'recursos': CYAN}


def t_setup(wmm, hmm, grid=True):
    fig, ax = axes_mm(wmm, hmm, (-2, 102), (-2, 72))
    if grid:
        for x in np.arange(0, 101, 2):
            ax.plot([x, x], [0, 70], color='#EAEAEA', lw=.25, zorder=0)
        for y in np.arange(0, 71, 2):
            ax.plot([0, 100], [y, y], color='#EAEAEA', lw=.25, zorder=0)
        xx, yy = np.meshgrid(np.arange(0, 101, 4), np.arange(0, 71, 4))
        ax.scatter(xx.ravel(), yy.ravel(), s=.6, color='#BDBDBD', zorder=1, linewidths=0)
    ax.add_patch(Rectangle((0, 0), 100, 70, fill=False, ec=INK, lw=.5))
    return fig, ax


def t_curve(ax, seq, color, offset=0, alpha=.7, lw=1.0):
    pts = [nodes[n] for n in seq]
    for j, (p, q) in enumerate(zip(pts[:-1], pts[1:])):
        x, y = p
        X, Y = q
        dx, dy = X - x, Y - y
        d = max(math.hypot(dx, dy), .01)
        nx, ny = -dy / d, dx / d
        bend = offset + 2.5 * ((j % 2) * 2 - 1)
        path = MPath([(x, y), (x + dx * .33 + nx * bend, y + dy * .33 + ny * bend), (x + dx * .68 + nx * bend, y + dy * .68 + ny * bend), (X, Y)],
                     [MPath.MOVETO, MPath.CURVE4, MPath.CURVE4, MPath.CURVE4])
        ax.add_patch(PathPatch(path, fill=False, ec=color, lw=lw, alpha=alpha, zorder=3, capstyle='round'))


def t_fields(ax):
    for k in ['D1', 'D2', 'D3', 'D4']:
        x, y = nodes[k]
        ax.add_patch(Ellipse((x, y), 20, 18, fc=VIOLET, alpha=.07, ec='none', zorder=1))
        ax.add_patch(Ellipse((x, y), 14, 12, fill=False, ec=VIOLET, lw=.4, ls=(0, (2, 2)), alpha=.5, zorder=1))
    for k, w, h, cc in [('C', 31, 22, PINK), ('K', 24, 17, GOLD), ('T', 23, 16, CYAN), ('W', 18, 13, CYAN), ('A', 17, 12, PINK), ('R', 23, 12, GREEN)]:
        x, y = nodes[k]
        ax.add_patch(Ellipse((x, y), w, h, fc=cc, alpha=.08, ec='none', zorder=1))


def t_points(ax, small=False):
    for k, (x, y) in nodes.items():
        ax.scatter([x], [y], s=(14 if small else 26) if k[0] != 'D' else (9 if small else 16), c=[PINK if k in ['C', 'K', 'A'] else INK],
                   edgecolors='white', linewidths=.5, zorder=7)
        ax.text(x + 1.3, y + 1.3, tlabels[k], fontsize=5.5 if small else 7.5, fontstyle='italic', color=INK, zorder=8,
                bbox=dict(fc='white', ec='none', pad=.4, alpha=.85))


fig, ax = t_setup(270, 190)
t_fields(ax)
for i, (sid, typ, seq) in enumerate(routes):
    t_curve(ax, seq, tcol[typ], offset=(i % 5 - 2) * 1.8, alpha=.75, lw=.95)
t_points(ax)
save(fig, 'tejido_general')

fig, ax = t_setup(270, 190)
t_fields(ax)
for i in [2, 4, 3, 7, 6, 14]:
    sid, typ, seq = routes[i]
    t_curve(ax, seq, tcol[typ], offset=(i % 3 - 1) * 2, alpha=.85, lw=1.5)
t_points(ax)
for lab, center in [('X1', (40, 45)), ('X2', (65, 25)), ('X3', (58, 17))]:
    ax.add_patch(Circle(center, 4, fill=False, ec=PINK, lw=1.1, zorder=9))
    it(ax, center[0], center[1], lab, 8, color=PINK, zorder=9)
save(fig, 'tejido_cruces')

for name, ids in [('manana', ['S03', 'S05']), ('tarde', ['S05', 'S10', 'S08']), ('noche', ['S04', 'S11', 'S16'])]:
    fig, ax = t_setup(128, 90)
    t_fields(ax)
    for i, (sid, typ, seq) in enumerate(routes):
        if sid in ids:
            t_curve(ax, seq, tcol[typ], offset=(i % 5 - 2) * 1.8, alpha=.9, lw=1.3)
        else:
            t_curve(ax, seq, '#CFCFCF', offset=(i % 5 - 2) * 1.8, alpha=.5, lw=.3)
    t_points(ax, small=True)
    save(fig, 'tejido_' + name)

# ------------------------------------------------------------ calibración con el cuerpo, 1:50
fig, ax = scaled(-.2, 10.3, -.75, 4.5, 50)
for x in np.arange(0, 10.01, .25):
    ax.plot([x, x], [-.5, 4.25], color='#EDEDED', lw=.3, zorder=0)
for y in np.arange(-.5, 4.26, .25):
    ax.plot([0, 10], [y, y], color='#EDEDED', lw=.3, zorder=0)
ax.plot([.3, .3], [.3, 3.6], color=INK, lw=2.4, solid_capstyle='butt')
ax.add_patch(Rectangle((.3, .6), 1.8, .9, fc=CYAN, alpha=.45, ec=INK, lw=.4))
ax.plot([.3, .3], [.6, 1.5], color=PINK, lw=3, solid_capstyle='butt')
ax.add_patch(Rectangle((.8, 1.5), .9, .9, fill=False, ec=CYAN, ls=(0, (3, 2)), lw=.6))
ax.add_patch(Circle((1.25, 1.95), .2, fc=CYAN))
it(ax, 1.2, 1.05, 'tablero 1,80 × 0,90', 8)
it(ax, .45, -.25, 'bisagra en el canto corto', 7, ha='left')
ax.add_patch(Circle((4.5, 1.5), 1.05, fc='#E9CFA2', ec=INK, lw=.4))
ax.add_patch(Circle((4.5, 1.5), 1.6, fill=False, ec=VIOLET, ls=(0, (3, 2)), lw=.7))
it(ax, 4.5, 1.5, 'descanso\nØ 2,10', 8)
it(ax, 4.5, -.4, 'anillo de paso alrededor', 7)
ax.add_patch(Ellipse((8, 1.6), 1.5, .8, fc=PINK, alpha=.4, ec=INK, lw=.4))
for xx, yy in [(7.3, .8), (8.7, .8), (8, 2.55)]:
    ax.add_patch(Circle((xx, yy), .24, fc=PINK, alpha=.4))
it(ax, 8, -.4, 'tres cuerpos y un apoyo', 7)
for x, t in [(1.2, 'dibujar'), (4.5, 'dormir'), (8.0, 'estar')]:
    ax.text(x, 3.95, t, fontsize=10, color=INK, ha='center', fontstyle='italic')
save(fig, 'calibracion')

# ------------------------------------------------------------ matriz de relaciones
ids = [a['id'] for a in ACC]
names = [a['accion'] for a in ACC]
N = len(ids)
tv = {'PROXIMIDAD': CYAN, 'PROTEGER': PINK, 'POR_TURNOS': GOLD, 'CONDICIONAL': VIOLET}
fig = plain(220, 210)
ax = fig.add_axes([.25, .02, .74, .78])
ax.set_xlim(-.5, N - .5)
ax.set_ylim(N - .5, -.5)
ax.set_aspect('equal')
for i in range(N):
    for j in range(N):
        ax.add_patch(Rectangle((j - .46, i - .46), .92, .92, fc='#F2F2F2', ec='none'))
for r in REL:
    i, j = ids.index(r['a']), ids.index(r['b'])
    for a_, b_ in [(i, j), (j, i)]:
        ax.add_patch(Rectangle((b_ - .46, a_ - .46), .92, .92, fc=tv[r['tipo']], ec='none'))
for i in range(N):
    ax.text(-.9, i, f"{names[i]}", ha='right', va='center', fontsize=9, color=INK)
    ax.text(i, -.9, ids[i][1:], ha='center', va='bottom', fontsize=6.5, color=GREY, fontstyle='italic')
    ax.text(-.9 - 0, i, '', fontsize=1)
ax.axis('off')
save(fig, 'matriz')

# ------------------------------------------------------------ tres tejidos sobre retícula
for res in RES:
    p = {k: tuple(v) for k, v in res['positions'].items()}
    fig, ax = axes_mm(128, 92, (-.8, 12.8), (-.8, 8.8))
    for x in range(13):
        ax.plot([x, x], [0, 8], c='#EAEAEA', lw=.35, zorder=0)
    for y in range(9):
        ax.plot([0, 12], [y, y], c='#EAEAEA', lw=.35, zorder=0)
    for r in REL:
        i, j = r['a'], r['b']
        (x, y), (X, Y) = p[i], p[j]
        t = r['tipo']
        bend = .15 * ((ids.index(i) + ids.index(j)) % 3 - 1)
        path = MPath([(x, y), (x + (X - x) * .3, y + (Y - y) * .3 + bend), (x + (X - x) * .7, y + (Y - y) * .7 + bend), (X, Y)], [1, 4, 4, 4])
        ax.add_patch(PathPatch(path, ec=tv[t], fc='none', lw=.8 if t in ['PROXIMIDAD', 'PROTEGER'] else .6,
                               alpha=.9 if t in ['PROXIMIDAD', 'PROTEGER'] else .55, ls='-' if t in ['PROXIMIDAD', 'PROTEGER'] else (0, (2, 1.5)), zorder=2))
    for k, (x, y) in p.items():
        ax.add_patch(Circle((x, y), .3, fc='white', ec=INK, lw=.5, zorder=5))
        ax.text(x, y, k[1:], ha='center', va='center', fontsize=5.5, color=INK, zorder=6)
    save(fig, f"tejido_reglas_{res['alternative']}")
print('ok')
