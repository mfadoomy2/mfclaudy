# -*- coding: utf-8 -*-
# Plantas, lecturas relacionales, habitación, bow y servicios, redibujadas a escala desde la geometría del proyecto.
import sys, math, json
sys.path.insert(0, '/home/claude/g3/build')
sys.path.insert(0, '/home/claude/g3/w/G3_DOCUMENTO_PLANTAS_NUEVAS_CORREGIDAS_2026-10-19/fuentes')
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    import geometria as G
from estilo import *
import numpy as np
from matplotlib.patches import Polygon as Patch, FancyArrowPatch
from shapely.geometry import Point, LineString, box, Polygon
from shapely.ops import unary_union


def polys(g):
    if g.is_empty:
        return []
    return [g] if g.geom_type == 'Polygon' else [p for p in getattr(g, 'geoms', []) if p.geom_type == 'Polygon']


def draw(ax, g, fc, ec='none', lw=.4, z=1):
    for p in polys(g):
        ax.add_patch(Patch(np.array(p.exterior.coords), facecolor=fc, edgecolor=ec, lw=lw, zorder=z, joinstyle='round'))
        for h in p.interiors:
            ax.add_patch(Patch(np.array(h.coords), facecolor='white', edgecolor=ec, lw=lw, zorder=z))


def line(ax, g, c, lw=1, ls='-', z=3):
    ls_ = [g] if g.geom_type == 'LineString' else [l for l in getattr(g, 'geoms', []) if l.geom_type == 'LineString']
    for l in ls_:
        x, y = l.xy
        ax.plot(x, y, color=c, lw=lw, ls=ls, zorder=z, solid_capstyle='round', dash_capstyle='round')


def furncol(k):
    return C['seat'] if k == 'bow_asiento' else C['ward'] if k == 'vestidor' else C['desk'] if k in ['mesa_A1', 'taburete_en_uso'] else C['bed']


def label_point(r):
    """Punto libre dentro de la habitación para el número, fuera de muebles."""
    poly = r['poly']
    furn = unary_union([r['T'](G.tf(g, r['r'])) for g in G.FURN.values()])
    free = poly.buffer(-.15).difference(furn.buffer(.18))
    best = max(polys(free), key=lambda p: p.area)
    return best.representative_point()


def render(ax, f, diagram=False, labels=True):
    draw(ax, f['floor'], C['floor'])
    for b in f['banks']:
        draw(ax, b['floor'], C['service'])
    for r in f['rooms']:
        draw(ax, r['poly'], C['private'])
        if not diagram:
            for k, g in G.FURN.items():
                draw(ax, r['T'](G.tf(g, r['r'])), furncol(k), ec='#5E7466', lw=.25, z=2)
            draw(ax, r['T'](G.tf(G.WIN, r['r'])), C['glass'], z=4)
            line(ax, r['T'](G.tf(G.TEXTILE, r['r'])), C['seat'], .7, (0, (3, 2)))
    if not diagram:
        draw(ax, f['solid'], C['wall'], z=3)
        for w in f['wc']:
            draw(ax, w, C['glass'], z=4)
        for bank in f['banks']:
            for b0 in f['u']['bank']['baths0']:
                x, y, X, Y = b0.bounds
                draw(ax, bank['T'](b0), C['bath'], z=2)
                for g, c in [(box(X - .9, y + .08, X - .08, y + .9), '#E4EEEA'), (Point(X - .4, Y - .42).buffer(.22), 'white'), (box(x + .1, Y - .5, x + .5, Y - .12), 'white')]:
                    draw(ax, bank['T'](g), c, C['wall'], .25, z=3)
        for k in f['kitchens']:
            draw(ax, k, C['ward'], C['wall'], .3, z=2)
        for k in f['utility']:
            draw(ax, k, '#97A99C', C['wall'], .3, z=2)
        for k in f['work'] + f['tables']:
            draw(ax, k, C['desk'], C['wall'], .3, z=2)
        for k in f['chairs']:
            draw(ax, k, C['desk'], C['wall'], .3, z=2)
        for k in f['sofas']:
            draw(ax, k, C['seat'], C['wall'], .3, z=2)
        if labels:
            for r in f['rooms']:
                p = label_point(r)
                it(ax, p.x, p.y, r['id'], 6.5, zorder=6)
    else:
        food = f['tables'][0].centroid if f['tables'] else f['kitchens'][0].centroid
        talk = f['sofas'][0].centroid
        cook = f['kitchens'][0].centroid
        for r in f['rooms']:
            p = r['T'](G.tf(G.BED.centroid, r['r']))
            line(ax, LineString([p, talk]), PINK, .55, (0, (2.5, 1.8)), z=3)
        line(ax, LineString([food, cook]), CYAN, 1.2, z=4)
        line(ax, LineString([food, talk]), CYAN, 1.2, z=4)
        for p, t, c in [(food, 'comer', C['desk']), (cook, 'preparar', C['ward']), (talk, 'estar', C['seat'])]:
            ax.plot(p.x, p.y, 'o', ms=4.5, color=c, zorder=6, mec='white', mew=.6)
            ax.annotate(t, (p.x, p.y), xytext=(0, 6), textcoords='offset points', ha='center', va='bottom', fontsize=6.5, fontstyle='italic', color=INK, zorder=7)
        for b in f['banks']:
            p = b['floor'].centroid
            ax.plot(p.x, p.y, 's', ms=4.5, color='#7996A3', zorder=6, mec='white', mew=.6)
            ax.annotate('aseos', (p.x, p.y), xytext=(0, 6), textcoords='offset points', ha='center', va='bottom', fontsize=6.5, fontstyle='italic', color=INK, zorder=7)
        for r in f['rooms']:
            p = label_point(r)
            it(ax, p.x, p.y, r['id'], 5.5, color='#4A4A4A', zorder=6)
    # entrada
    ex, ey = f['entry']['outside']
    ix, iy = f['entry']['inside']
    if labels:
        ax.add_patch(FancyArrowPatch((ex, ey), (ix, iy), arrowstyle='-|>', mutation_scale=7, color=C['route'], lw=1, zorder=8))


def extent(f, pad=1.2):
    x, y, X, Y = f['floor'].bounds
    return x - pad, X + pad, y - pad, Y + pad


def scalebar(ax, x, y, L=5, scale=100):
    ax.plot([x, x + L], [y, y], color=INK, lw=.8, solid_capstyle='butt')
    for t in range(0, L + 1):
        ax.plot([x + t, x + t], [y, y + (.18 if t in (0, L) else .1)], color=INK, lw=.5)
    it(ax, x + L + .3, y + .05, f'{L} m', 6.5, ha='left', va='center')


info = {}
for f in G.F:
    code = f['audit']['codigo']
    unit = code.endswith('_U')
    sc = 100 if unit else 150
    x0, x1, y0, y1 = extent(f, 1.3)
    y0 -= 1.0
    fig, ax = scaled(x0, x1, y0, y1, sc)
    render(ax, f)
    scalebar(ax, x0 + 1.3, y0 + .6)
    save(fig, f'planta_{code}')
    # lectura relacional, más pequeña
    x0, x1, y0, y1 = extent(f, 1.0)
    fig, ax = scaled(x0, x1, y0, y1, 250 if unit else 330)
    render(ax, f, diagram=True)
    save(fig, f'lectura_{code}')
    x0, x1, y0, y1 = extent(f, .2)
    fig, ax = scaled(x0, x1, y0, y1, 600)
    render(ax, f, labels=False)
    save(fig, f'mini_{code}')
    info[code] = {k: f['audit'][k] for k in ['habitantes', 'suelo_m2', 'envolvente_estudio_m2', 'banos']}
    info[code]['escala'] = sc

# Tres casas a la misma escala (1:200) en cajas iguales
for f in G.F[:3]:
    code = f['audit']['codigo']
    x, y, X, Y = f['floor'].bounds
    cx, cy = (x + X) / 2, (y + Y) / 2
    fig, ax = scaled(cx - 9.6, cx + 9.6, cy - 9.6, cy + 9.6, 220)
    render(ax, f)
    save(fig, f'comparar_{code}')

# ---------------------------------------------------------------- habitación
def room_state(open_desk=True):
    fig, ax = scaled(-.45, 5.15, -.75, 5.35, 50)
    draw(ax, G.ROOM, C['private'])
    for k, g in G.FURN.items():
        if not open_desk and k in ['mesa_A1', 'taburete_en_uso']:
            continue
        draw(ax, g, furncol(k), ec='#5E7466', lw=.3, z=2)
    if not open_desk:
        draw(ax, box(.07, .10, .12, 1.0), C['desk'], z=2)
        draw(ax, Point(.65, .7).buffer(.23), C['desk'], z=2)
        line(ax, G.DESK.boundary, '#8FA394', .5, (0, (2, 2)))
    draw(ax, G.ROOM.boundary.buffer(.06).difference(G.DOOR).difference(G.WIN), C['wall'], z=3)
    draw(ax, G.WIN, C['glass'], z=4)
    line(ax, G.TEXTILE, C['seat'], .8, (0, (3, 2)))
    line(ax, LineString([(2.6, -.35), (2.6, 1.5), (2.4, 3.55)]), C['route'], .7, (0, (3, 2)))
    line(ax, LineString([(2.6, 3.1), (3.2, 3.1)]), C['route'], .7, (0, (3, 2)))
    it(ax, .875, 3.0, 'cama\n1,25 × 2,00', 7, zorder=6)
    if open_desk:
        it(ax, .93, .48, 'tablero 1,80 × 0,90', 7, zorder=6)
    else:
        it(ax, 1.25, .55, 'tablero\nrecogido', 7, zorder=6)
    it(ax, 3.62, 3.28, 'vestidor', 7, zorder=6)
    it(ax, 1.8, 4.62, 'bow', 7, zorder=6)
    it(ax, 2.6, -.6, 'puerta 1,00', 6.5)
    return fig


save(room_state(True), 'habitacion_abierta')
save(room_state(False), 'habitacion_recogida')

# vestidor 1:20
fig, ax = scaled(2.55, 5.0, 1.35, 4.75, 25)
draw(ax, G.ROOM, C['private'])
draw(ax, G.WARD, C['ward'], z=2)
draw(ax, G.ROOM.boundary.buffer(.06).difference(G.DOOR).difference(G.WIN), C['wall'], z=3)
ax.plot([3.25, 4.15], [3.1, 3.1], color=INK, lw=.6)
ax.plot([4.15, 4.70], [3.1, 3.1], color='white', lw=.6, zorder=4)
for xx in (3.25, 4.15):
    ax.plot([xx, xx], [3.04, 3.16], color=INK, lw=.6)
it(ax, 3.70, 3.25, '0,90', 8)
it(ax, 4.43, 3.25, '0,55', 8, color='white', zorder=5)
it(ax, 3.62, 2.75, 'radio libre', 7)
it(ax, 4.43, 2.80, 'ropa', 7, color='white', zorder=5)
save(fig, 'vestidor')

# bow, planta 1:20
fig, ax = scaled(-.25, 3.45, 3.55, 5.35, 20)
base = G.ROOM.intersection(box(-1, 3.5, 6, 6))
draw(ax, base, C['private'])
draw(ax, G.SEAT, C['seat'], ec='#5E7466', lw=.3, z=2)
draw(ax, G.ROOM.boundary.buffer(.06).difference(G.DOOR).difference(G.WIN).intersection(box(-1, 3.5, 6, 6)), C['wall'], z=3)
draw(ax, G.WIN, C['glass'], z=4)
line(ax, G.TEXTILE, C['seat'], .9, (0, (3, 2)))
bc = G.BC
it(ax, bc[0] + .08, 4.12, 'asiento curvo, fondo 0,57', 7, ha='center')
it(ax, bc[0] + .5, 5.22, 'vidrio curvo, radio 1,25', 7)
it(ax, .33, 4.60, 'vuelo\n0,60', 7, ha='right')
ax.plot([.37, .45], [4.30, 4.30], color=INK, lw=.5)
ax.plot([.37, .45], [4.90, 4.90], color=INK, lw=.5)
ax.plot([.41, .41], [4.30, 4.90], color=INK, lw=.5)
save(fig, 'bow_planta')

# bow, sección 1:20 (sin figuras humanas)
fig, ax = scaled(-1.25, .95, -.55, 3.35, 25)
ax.add_patch(Patch(np.array([(-1.25, -.25), (.75, -.25), (.75, 0), (-1.25, 0)]), fc=C['bed'], ec='none'))
ax.add_patch(Patch(np.array([(-1.25, 3.0), (.75, 3.0), (.75, 3.25), (-1.25, 3.25)]), fc=C['wall'], ec='none'))
ax.add_patch(Patch(np.array([(.535, 0), (.665, 0), (.665, .80), (.535, .80)]), fc=C['wall'], ec='none'))
ax.add_patch(Patch(np.array([(.578, .80), (.622, .80), (.622, 3.0), (.578, 3.0)]), fc=C['glass'], ec='none'))
ax.add_patch(Patch(np.array([(-.05, 0), (.52, 0), (.52, .42), (-.05, .42)]), fc=C['bed'], ec='#5E7466', lw=.3))
ax.add_patch(Patch(np.array([(-.05, .42), (.52, .42), (.52, .46), (-.05, .46)]), fc=C['seat'], ec='none'))
ax.add_patch(Patch(np.array([(.46, .46), (.535, .46), (.535, .80), (.46, .80)]), fc=C['seat'], ec='none'))
ax.plot([.80, .80], [.35, 2.9], color=C['seat'], lw=.9, ls=(0, (3, 2)))
ax.add_patch(Patch(np.array([(-1.25, 0), (-.06, 0), (-.06, 3.0), (-1.25, 3.0)]), fc='none', ec='none'))


def dim_v(x, z0, z1, txt, side='l'):
    ax.plot([x, x], [z0, z1], color=INK, lw=.5)
    for z in (z0, z1):
        ax.plot([x - .04, x + .04], [z, z], color=INK, lw=.5)
    it(ax, x + (-.07 if side == 'l' else .07), (z0 + z1) / 2, txt, 7, ha='right' if side == 'l' else 'left')


dim_v(-.25, 0, .46, '0,46')
dim_v(-.55, 0, .80, '0,80')
ax.plot([-.06, .60], [-.36, -.36], color=INK, lw=.5)
for xx in (-.06, .60):
    ax.plot([xx, xx], [-.40, -.32], color=INK, lw=.5)
it(ax, .27, -.42, 'vuelo 0,60', 7, va='top')
it(ax, .84, 1.7, 'tela', 7, ha='left')
save(fig, 'bow_seccion')

# ---------------------------------------------------------------- servicios en borde, detalle 1:50
f = G.F[0]
b = f['banks'][0]
x, y, X, Y = b['floor'].bounds
fig, ax = scaled(x - .5, X + 2.4, y - .6, Y + .6, 30)
render(ax, f)
for dc in b['door_centres']:
    ray = LineString([b['view'], dc])
    hit = ray.intersection(f['solid'])
    pts = []
    for g in ([hit] if hit.geom_type == 'LineString' else getattr(hit, 'geoms', [])):
        if g.geom_type == 'LineString':
            pts += [Point(*g.coords[0]), Point(*g.coords[-1])]
    if pts:
        stop = min(pts, key=lambda p: p.distance(b['view']))
        line(ax, LineString([b['view'], stop]), PINK, .8, (0, (3, 2)), z=7)
        ax.plot(stop.x, stop.y, 'x', color=PINK, ms=4, mew=.8, zorder=7)
vx, vy = b['view'].x, b['view'].y
ax.plot(vx, vy, 'o', ms=3, color=PINK, zorder=8)
it(ax, vx + .25, vy, 'desde el estar', 7, ha='left', zorder=8)
for i, bb in enumerate(b['baths']):
    c = bb.centroid
    it(ax, c.x, c.y, 'aseo', 7, zorder=8)
p = b['screen'].centroid
it(ax, p.x - .35, p.y + .95, 'filtro', 7, zorder=8)
save(fig, 'servicios_detalle')

json.dump(info, open(OUT / 'plantas_info.json', 'w'), indent=1)
print(json.dumps(info, indent=1))
