import sys, json
sys.path.insert(0, '/home/claude/g3/build')
from estilo import *
info = json.load(open(OUT / 'plantas_info.json'))
order = ['V01_U', 'V02_U', 'V03_U', 'V02_P', 'V01_S', 'V01_D', 'V03_S', 'V03_D']
names = {'V01_U': 'Convivencia continua', 'V02_U': 'Dos ámbitos', 'V03_U': 'Centro libre', 'V02_P': 'Pareja con umbral',
         'V01_D': 'Encuentro mayor', 'V01_S': 'Casa común continua', 'V03_D': 'Plaza entre estancias', 'V03_S': 'Continuidad diagonal'}
fig = plain(200, 120)
ax = fig.add_axes([.30, .14, .66, .84])
for i, c in enumerate(order):
    d = info[c]
    pp = d['envolvente_estudio_m2'] / d['habitantes']
    y = len(order) - 1 - i + (0 if i < 3 else -.0)
    col = CYAN if d['habitantes'] == 4 else PINK
    ax.plot([34, pp], [y, y], color=col, lw=1.4, solid_capstyle='butt')
    ax.plot(pp, y, 'o', color=col, ms=5, mec='white', mew=.6)
    ax.text(pp + .25, y, f'{pp:.1f}'.replace('.', ','), fontsize=8, va='center', color=INK, fontstyle='italic')
    ax.text(33.6, y, names[c], fontsize=8.5, va='center', ha='right', color=INK)
ax.set_xlim(34, 43.5)
ax.set_ylim(-.7, len(order) - .3)
ax.set_yticks([])
for s in ['top', 'right', 'left']:
    ax.spines[s].set_visible(False)
ax.spines['bottom'].set_linewidth(.5)
ax.tick_params(labelsize=7.5, width=.5, length=3)
ax.set_xlabel('m² de envolvente por residente', fontsize=8, fontstyle='italic')
ax.patch.set_alpha(0)
save(fig, 'superficie_persona')
for c in order:
    d = info[c]; print(c, round(d['envolvente_estudio_m2'] / d['habitantes'], 2))
