# -*- coding: utf-8 -*-
# Estilo común de figuras: Ibarra Real Nova, fondo transparente sobre página blanca.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from pathlib import Path

FONTS = Path('/home/claude/g3/fonts')
for f in FONTS.glob('*.ttf'):
    fm.fontManager.addfont(str(f))
matplotlib.rcParams.update({
    'font.family': 'Ibarra Real Nova',
    'pdf.fonttype': 42,
    'font.size': 8,
    'axes.unicode_minus': False,
    'svg.fonttype': 'none',
})

OUT = Path('/home/claude/g3/build/fig')
OUT.mkdir(parents=True, exist_ok=True)

INK = '#141414'
GREY = '#8A8A8A'
LIGHT = '#D9D9D9'
PINK = '#D63C8A'
CYAN = '#12A9AE'
GOLD = '#D9A21E'
VIOLET = '#7E52B8'
GREEN = '#3E9E6E'

# Paleta de plantas (la del proyecto)
C = {'floor': '#EFE8D9', 'private': '#D8E2D0', 'wall': '#3F5649', 'bed': '#C9A97F', 'desk': '#B9764B',
     'ward': '#6F937F', 'seat': '#CC5F93', 'glass': '#1E9EA3', 'bath': '#9DB8C2', 'service': '#DCE5E6',
     'route': '#C13F55'}

MM = 1 / 25.4


def scaled(xmin, xmax, ymin, ymax, scale):
    """Figura a escala real: 1 m de modelo = 1000/scale mm de papel."""
    w = (xmax - xmin) * 1000 / scale * MM
    h = (ymax - ymin) * 1000 / scale * MM
    fig = plt.figure(figsize=(w, h))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.axis('off')
    ax.patch.set_alpha(0)
    fig.patch.set_alpha(0)
    return fig, ax


def plain(wmm, hmm):
    fig = plt.figure(figsize=(wmm * MM, hmm * MM))
    fig.patch.set_alpha(0)
    return fig


def save(fig, name):
    fig.savefig(OUT / (name + '.pdf'), transparent=True)
    fig.patch.set_alpha(1)
    fig.patch.set_facecolor('white')
    fig.savefig(OUT / (name + '.png'), facecolor='white', dpi=110)
    plt.close(fig)


def it(ax, x, y, s, size=7, color=INK, ha='center', va='center', **kw):
    return ax.text(x, y, s, fontsize=size, color=color, ha=ha, va=va, fontstyle='italic', **kw)


def rm(ax, x, y, s, size=7, color=INK, ha='center', va='center', **kw):
    return ax.text(x, y, s, fontsize=size, color=color, ha=ha, va=va, **kw)
